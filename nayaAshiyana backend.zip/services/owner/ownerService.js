const Owner = require("../../models/ownersModel")
const bcrypt = require('bcrypt');
const jwt = require("jsonwebtoken")
const mongoose = require("mongoose")
const nodemailer = require("nodemailer");
const { transporter, generateOTP } = require("../../utilities/customFunction")
const message = require("../../utilities/messages");



// signup owner service
exports.SignupOwnerServices = async (req, res) => {

    const { name, email, phone, password, city } = req.body

    // Validate the request body
    if (!name || !email || !phone || !password) {
        const error = new Error('Missing required fields');
        error.statusCode = 400;
        throw error;
    }
    const existingUser = await Owner.findOne({ email });
    const salt = await bcrypt.genSalt(10);
    if (existingUser) {
        const error = new Error('owner already exists');
        error.statusCode = 400;
        throw error;
    }
    const owner = new Owner({
        name,
        email,
        phone,
        password: await bcrypt.hash(password, salt),
        isActive: true,
    });
    await owner.save();
    return owner
}

// sending otp for owner 
// exports.sendOtpServices = async (req, res) => {

//     const { email } = req.body;
//     // Generate a random OTP
//     const otp = generateOTP();

//     // Check if the owner exists and update OTP
//     const owner = await Owner.findOneAndUpdate({ email }, { otp }, { new: true });

//     if (!owner) {
//         const error = new Error("Owner not found");
//         error.statusCode = 400;
//         throw error;
//     }

//     // Send the OTP to the owner's email
//     const mailOptions = {
//         from: `"NayaAshiyana Login Code" <testingsdd123@gmail.com>`,
//         to: email,
//         subject: "OTP for Login",
//         text: `Your OTP for login is: ${otp}`,
//     };

//     transporter.sendMail(mailOptions, (error, info) => {
//         if (error) {
//             console.error(error);
//             const error = new Error("Failed to send OTP");
//             error.statusCode = 400;
//             throw error;

//         } else {
//             
//             return owner
//         }
//     });

// };
exports.sendOtpServices = async (req, res) => {
    const { email } = req.body;

    // Generate a random OTP
    const otp = generateOTP();

    try {
        // Check if the owner exists and update OTP
        const owner = await Owner.findOneAndUpdate({ email }, { otp }, { new: true });

        if (!owner) {
            const error = new Error("Owner not found");
            error.statusCode = 400;
            throw error;
        }

        // Send the OTP to the owner's email
        const mailOptions = {
            from: `"NayaAshiyana Login Code" <testingsdd123@gmail.com>`,
            to: email,
            subject: "OTP for Login",
            text: `Your OTP for login is: ${otp}`,
        };

        // Wrap the sending of email in a Promise
        const sendMailPromise = new Promise((resolve, reject) => {
            transporter.sendMail(mailOptions, (error, info) => {
                if (error) {
                    console.error(error);
                    reject(new Error("Failed to send OTP"));
                } else {
                    resolve(owner);
                }
            });
        });

        // Wait for the email to be sent before returning the owner
        const updatedOwner = await sendMailPromise;
        return updatedOwner;
    } catch (error) {
        console.error(error);
        throw error; // Rethrow the error for the controller to handle
    }
};


//   login owner
exports.LoginServices = async (req, res) => {
    const { email, otp } = req.body;

    // Check if the owner with the given email exists
    const owner = await Owner.findOne({ email });

    if (!owner) {
        const error = new Error("Owner not found");
        error.statusCode = 400;
        throw error;
    }

    // Check if the OTP matches
    if (otp === owner.otp) {

        owner.isActive = true;
        owner.save();
        let token = jwt.sign({ owner: owner, isOwner: true }, "mynameisgiri");
        return {owner , token:token}
        return res.json({ success: true, token: token, owner: owner, message: "Logged in successfully" });
    } else {
        const error = new Error("Invalid OTP");
        error.statusCode = 400;
        throw error;
    }
   
}


// get owner services 
exports.getOwnerServices = async (req, res) => {
    const users = await Owner.find();
    return users
}

// updating owner services 
exports.updateOwnerServices = async (req, res) => {

    const { name, email, phone, password, isActive } = req.body;
    const { id } = req.params.id;

    // Validate the request body
    if (!name || !email || !password || !phone) {
        const error = new Error('Missing required fields');
        error.statusCode = 400;
        throw error;
    }

    // Check if the owner exists
    const owner = await Owner.findById(id);
    if (!owner) {
        const error = new Error("Owner not found");
        error.statusCode = 400;
        throw error;
    }

    // Update the owner
    owner.name = name;
    owner.email = email;
    owner.phone = phone;
    owner.password = password;
    owner.isActive = isActive;

    // Save the owner
    await owner.save();

    // Send a 200 OK response
    res.status(200).json({ owner });
};

// Delete a owner services 
exports.deleteOwnerService = async (req, res) => {

    const { id } = req.params;
    // Validate the request parameter
    if (!id) {
        const error = new Error('Missing required fields');
        error.statusCode = 400;
        throw error;
    }
    // Check if the customer exists
    const owner = await Owner.findByIdAndRemove(id);
    if (!owner) {
        const error = new Error('owner not found');
        error.statusCode = 400;
        throw error;
    }
}