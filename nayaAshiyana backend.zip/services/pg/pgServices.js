const Owner = require("../../models/ownersModel")
const PG = require("../../models/pgDetails")
const mongoose = require("mongoose")
// const path = require("path")
const path = "http://localhost:4500"



// for creating pg services
exports.CreatePgService = async (req, res) => {
  let images = []
  if (req.files) {

    for (let i = 0; i < req.files.length; i++) {
      const file = req.files[i];
      images.push(`/${file.path}`);
    }
  }

  if (req.body.ratings) {
    req.body.ratings = JSON.parse(req.body.ratings);
  }
  if (req.body.area) {
    req.body.area = JSON.parse(req.body.area);
  }
  if (req.body.securityDeposit) {
    req.body.securityDeposit = JSON.parse(req.body.securityDeposit);
  }

  req.body.images = images;

  const newPg = new PG(req.body);
  const pg = await newPg.save()

  return pg
}

// for getting pg services by Pg Id
exports.getPgServices = async (req, res) => {
  const pgId = req.params.pgId;

  const Pg = await PG.aggregate([
    {
      "$match": { _id: new mongoose.Types.ObjectId(pgId) }
    },
    {
      $lookup: {
        from: 'owners',
        localField: "ownerId",
        foreignField: "_id",
        as: "own"
      }
    },
    {
      $unwind: "$own"
    },
    {
      $project: {
        name: "$name",
        category: "$category",
        furnished: "$furnished",
        addToFavorites: "$addToFavorites",
        numberOfRooms: "$numberOfRooms",
        Price: "$Price",
        facilities: "$facilities",
        availableRooms: "$availableRooms",
        ownerName: "$own.name",
        ownerEmail: "$own.email",
        ownerPhone: "$own.phone",
        ratings: "$ratings",
        images: "$images",
        description: "$description",
        rules: "$rules",
        nearbyLandmarks: "$nearbyLandmarks",
        area: "$area",
        city: "$city",
        type: "$type",
        parking: "$parking",
        RoomType: "$Private",
        ElectricityCharge: "$ElectricityCharge",
        FoodAvailable: "$FoodAvailable",
        FoodChargesInclude: "$FoodChargesInclude",
        securityDeposit: "$securityDeposit",
        independent: "$independent",
        extraCharges: "$extraCharges",
        numberOfBathrooms: "$numberOfBathrooms",
        numberOfBalconies: "$numberOfBalconies"
      }
    },
  ])


  return Pg

}

// for getting pg services  by owner id
exports.getPgByOwnersIdServices = async(req,res)=>{
  const ownerId = req.params.ownerId;

  // Perform aggregation to get details by ownerId
  const result = await PG.aggregate([
    {
      $match: {
        ownerId:new mongoose.Types.ObjectId(ownerId),
      },
    },
    {
      $lookup: {
        from: 'users',
        localField: 'ratings.ratedBy',
        foreignField: '_id',
        as: 'ratings.userDetails',
      },
    },
    {
      $lookup: {
        from: 'owners', // Collection name for users
        localField: 'ownerId', // Field in PG collection
        foreignField: '_id', // Field in users collection
        as: 'ownerDetails', // Store user details in ownerDetails field
      },
    },
    {
      $unwind: {
        path: '$ratings',
        preserveNullAndEmptyArrays: true,
      },
    },
    // {
    //   $group: {
    //     _id: '$_id',
    //     details: {
    //       $first: '$$ROOT',
    //     },
    //     ratings: {
    //       $push: {
    //         rating: '$ratings.rating',
    //         review: '$ratings.review',
    //         ratedBy: '$ratings.userDetails',
    //       },
    //     },
    //   },
    // },
    {
      $project: {
        name: "$name",
        category: "$category",
        furnished: "$furnished",
        addToFavorites: "$addToFavorites",
        numberOfRooms: "$numberOfRooms",
        Price: "$Price",
        facilities: "$facilities",
        availableRooms: "$availableRooms",
        ownerName: "$ownerDetails.name", // Access owner's name from ownerDetails
        ownerEmail: "$ownerDetails.email", // Access owner's email from ownerDetails
        ownerPhone: "$ownerDetails.phone",
        // ratings: "$ratings",
        images: "$images",
        description: "$description",
        rules: "$rules",
        nearbyLandmarks: "$nearbyLandmarks",
        area: "$area",
        city: "$city",
        type: "$type",
        parking: "$parking",
        RoomType: "$Private",
        ElectricityCharge: "$ElectricityCharge",
        FoodAvailable: "$FoodAvailable",
        FoodChargesInclude: "$FoodChargesInclude",
        securityDeposit: "$securityDeposit",
        independent: "$independent",
        extraCharges: "$extraCharges",
        numberOfBathrooms: "$numberOfBathrooms",
        numberOfBalconies: "$numberOfBalconies",
        isActive:"$isActive"
      }
    },
  ]);

  if (result.length === 0) {
    const error = new Error('PG not found for the given ownerId');
    error.statusCode = 400;
    throw error;

  }
  return result;
}

// for getting all pg 
exports.getAllPgService = async (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const itemsPerPage = parseInt(req.query.itemsPerPage) || 3;
  const skip = (page - 1) * itemsPerPage;
  const pgs = await PG.find()
    .skip(skip)
    .limit(itemsPerPage);
 
  return pgs
};

// getting all pg by city
exports.getAllPgByCityServices = async (req, res) => {

  const page = parseInt(req.query.page) || 1;
  const itemsPerPage = parseInt(req.query.itemsPerPage) || 2;
  const skip = (page - 1) * itemsPerPage;

  const pgs = await PG.find()
    .skip(skip)
    .limit(itemsPerPage);

 
  return pgs
};


// getting faviourite pg
exports.getPgByFavouriteService = async (req, res) => {

  const page = parseInt(req.query.page) || 1;
  const itemsPerPage = parseInt(req.query.itemsPerPage) || 3;
  const skip = (page - 1) * itemsPerPage;

  const favoritePGs = await PG.find({ addToFavorites: true })
    .skip(skip)
    .limit(itemsPerPage);

  if (favoritePGs.length === 0) {

    const error = new Error('No favorite PGs found.');
    error.statusCode = 400;
    throw error;
  }

  return favoritePGs;
};

// update fav pg
exports.updateFavPgService = async (req, res) => {
  const { id } = req.params;

  const pg = await PG.findById(id);

  pg.addToFavorites = !pg.addToFavorites;

  await pg.save();
  return pg
}

exports.updatePgService = async (req, res) => {

  const pgId = req.params.id;
  const updatedPGData = req.body;
  const updatedPG = await PG.findByIdAndUpdate(pgId, updatedPGData, { new: true });

  if (!updatedPG) {
    const error = new Error('PG not found');
    error.statusCode = 400;
    throw error;
  }

  return updatedPG

}

exports.deletePgService = async (req, res) => {

    const pgId = req.params.id;

    const deletedPG = await PG.findByIdAndRemove(pgId);

    if (!deletedPG) {
      const error = new Error('PG not found');
      error.statusCode = 400;
      throw error;
    }

  
}

exports.searchPgService = async (req, res) => {

    const city = req.query.city;

    const query = {};

    if (req.body !== null) {
      const {
        area,
        category,
        priceMin,
        priceMax,
        type

      } = req.body;

      if (type) {
        query.type = new RegExp(type, 'i');

      }

      if (area) {
        query['area.name'] = new RegExp(area, "i")
      }
      if (category) {
        query.category = new RegExp(category, "i");
      }

      if (priceMin && priceMax) {
        query.Price = { $gte: priceMin, $lte: priceMax };
      } else if (priceMin) {
        query.Price = { $gte: priceMin };
      } else if (priceMax) {
        query.Price = { $lte: priceMax };
      }
    }

    if (city) {
      query.city = new RegExp(city, "i");
    }

    const results = await PG.find(query);

    return results
  
};