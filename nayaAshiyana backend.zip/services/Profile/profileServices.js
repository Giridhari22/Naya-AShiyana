const Profile = require("../../models/ProfileModel");
const mongoose = require("mongoose")

exports.createProfileService = async (req, res) => {

    const {
        ownerId,
        f_name,
        l_name,
        email,
        phone,
        date_of_birth,
        city,
        state,
        zip_code,
        description,
        company_name,
        currency_name,
        employment_type
    } = req.body;

    // Access the image filename from req.file
    const image = req.file.filename;



    // Check required fields
    if (!ownerId || !f_name || !l_name || !email || !phone || !date_of_birth || !city || !state || !zip_code || !description || !image || !company_name || !currency_name || !employment_type) {
        const error = new Error('All Fields required');
        error.statusCode = 400;
        throw error;
    }

    // Create a new profile
    const newProfile = new Profile({
        ownerId,
        f_name,
        l_name,
        email,
        phone,
        date_of_birth,
        city,
        state,
        zip_code,
        description,
        image: image,
        company_name,
        currency_name,
        employment_type,
    });

    // Save the profile to the database
    const savedProfile = await newProfile.save();

    return savedProfile;
}


exports.deleteProfileServices = async (req, res) => {
    const profileId = req.params.profileId;

    // Validate the profileId
    if (!profileId) {
        const error = new Error("Profile ID is required.");
        error.statusCode = 400;
        throw error;
    }

    // Check if the profile with the given ID exists
    const existingProfile = await Profile.findById(profileId);
    if (!existingProfile) {
        const error = new Error("Profile not found.");
        error.statusCode = 400;
        throw error;
    }

    // Delete the profile
    const deleteProf = await Profile.findByIdAndDelete(profileId);
    return deleteProf;

}

exports.getProfileServices = async (req, res) => {

    const ownerId = req.params.ownerId;


    const ownerDetails = await Profile.aggregate([
        {
            "$match": { ownerId: new mongoose.Types.ObjectId(ownerId) }
        },
        {
            $lookup: {
                from: 'owners',
                localField: 'ownerId',
                foreignField: '_id',
                as: 'ownerDetails',
            },
        },
        {
            $unwind: '$ownerDetails',
        },
        {
            $project: {
                _id: 0,
                ownerId: '$ownerDetails._id',
                ownerName: "$ownerDetails.name",
                f_name: 1,
                l_name: 1,
                email: 1,
                phone: "$ownerDetails.phone",
                date_of_birth: 1,
                city: 1,
                state: 1,
                zip_code: 1,
                description: 1,
                image: 1,
                company_name: 1,
                currency_name: 1,
                employment_type: 1,
                isActive: 1,
            },
        },
    ]);

    return ownerDetails
}



