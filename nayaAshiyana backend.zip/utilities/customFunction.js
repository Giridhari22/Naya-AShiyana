const nodemailer = require("nodemailer");


exports.transporter = nodemailer.createTransport({
    service: "Gmail",
    auth: {
      user: 'testingsdd123@gmail.com',
      pass: 'yuxuyofxyjmdezlk'
    },
  });
  
  // Generate a random OTP
exports.generateOTP=()=> {
    return Math.floor(1000 + Math.random() * 9000);
  }