const mongoose = require("mongoose");

const messSchema = new mongoose.Schema({
    MessName: {
        type: String,
        trim: true, 
        minlength: 2, 
        maxlength: 50, 
    },
    Plans: {
        type: String,
        unique: true,     
    },
    Address: {
        type: Number,  
    },
    Ratings: {
        type: String,
     
    },
    Type: {
        type: String
    },
    isActive: {
        type: Boolean,
        default: true,
    },
}, { timestamps: true });

const Mess = mongoose.model('Mess', messSchema);

module.exports = Mess;
