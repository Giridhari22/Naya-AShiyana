const mongoose = require("mongoose");

const ownerSchema = new mongoose.Schema({
    name: {
        type: String,
        trim: true, 
        minlength: 2, 
        maxlength: 50, 
    },
    email: {
        type: String,
        unique: true,     
    },
    phone: {
        type: Number,  
    },
    password: {
        type: String,
     
    },
    otp: {
        type: String
    },
    isActive: {
        type: Boolean,
        default: true,
    },
}, { timestamps: true });

const Owner = mongoose.model('Owner', ownerSchema);

module.exports = Owner;
