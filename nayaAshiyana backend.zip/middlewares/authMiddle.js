const jwt = require("jsonwebtoken")
const authMiddle = (req, res, next) => {
    const token  = req.headers['authorization'];

  

    if (!token) return res.json({ message: "Token is not valid" })
    const decode = jwt.verify(token, "mynameisgiri");
    if (decode) {
        req.user = decode.user;        
        next()
    } else {
        res.json({ message: "Authorization Failed!" })
    }
}


module.exports= authMiddle
