
import React, { useEffect, useState } from 'react';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import "./BasicDetail.css"
import { useNavigate } from 'react-router-dom';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import 'bootstrap/dist/css/bootstrap.min.css'; // Import Bootstrap CSS
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import axios from 'axios';
import jwt_decode from "jwt-decode";


// this function is used in progress bar
const CustomProgressBar = ({ currentStep, steps }) => {

  const percent = ((currentStep - 1) / (steps - 1)) * 100;

  return (
    <div className="custom-progress-bar">
      <div
        className="progress-bar"
        style={{ width: `${percent}%` }}
      ></div>
    </div>
  );
};

// modal for facility section 
const FacilityModal = ({ isOpen, onClose, onSelectFacility, selectedFacilities = [] }) => {
  const facilities = ['Wifi', 'AC', 'Laundry', 'Comfortable beds', 'Dining area', 'Hot water supply', 'Television ', '24/7 electricity and water supply', 'CCTV', 'Washing machine', 'Power backup', 'maintenance', 'Yoga or meditation space', 'food available'];

  const isFacilitySelected = (facility) => (selectedFacilities || []).includes(facility);


  return (
    isOpen && (
      <div className="modal-overlay">
        <div className="modal-contents">
          <h2>Select Facilities</h2>
          <div>
            {facilities.map((facility) => (
              <button
                key={facility}
                type="button"
                style={{ margin: "10px", padding: "8px", borderRadius: "20px" }}
                className={isFacilitySelected(facility) ? 'btn btn-outline-success' : 'btn btn-outline-dark'}
                onClick={() => onSelectFacility(facility)}
              >
                {facility}
              </button>
            ))}
          </div>
          <button type="button" style={{  float: "right" }} className='btn btn-danger' onClick={onClose}>
            Close
          </button>
        </div>
      </div>
    )
  );
};

const BasicDetail = () => {

  const [currentStep, setCurrentStep] = useState(1);

  const navigate = useNavigate();
  const steps = 4;
  // const queryParams = new URLSearchParams(window.location.search);

  // const token = queryParams.get('token');
  // let decodeToken
  // if (token) {
  //   decodeToken = jwt_decode(token);
  //   console.log("decode owner", decodeToken)
  // }
  // if (token) {
  //   localStorage.setItem("token", token)

  // }
  // // Save the extracted data in local storage
  // if (decodeToken) {

  //   localStorage.setItem('owner', JSON.stringify({ name: decodeToken.owner.name, googleId: decodeToken.owner.googleId, email: decodeToken.owner.email, id: decodeToken.owner._id }));
  // }
  const [owner , setOwner] = useState(JSON.parse(localStorage.getItem("owner")));
  console.log("ownerId",owner._id)

  const formik = useFormik({
    initialValues: {
      city_name: '',
      pg_name: '',
      pgType: '',
      price: 0,
      securityDeposit: 0,
      duration: '',
      noOfRoom: 0,
      areaName: '',
      areaSize: '',

      // 2nd page
      category: '',
      furnished: '',
      roomType: '',
      electricityCharges: '',
      foodAvailable: [],
      foodCharges: '',
      parking: '',
      noOfBathrooms: 0,
      noOfBalcony: 0,
      independent: '',

      // 3rd page
      images: [],
      availableRoom: 0,
      nearByLandMarks: [],
      rules: [],
      facilities: [],
      extraCharges: [],
      description: ''
    },
    validationSchema: Yup.object({
      city_name: Yup.string().required('City Name is required'),
      pg_name: Yup.string().required('PG Name is required'),
      pgType: Yup.string().required('PG Type is required'),
      category: Yup.string().required('category is required'),

      price: Yup.number().required('Price is required'),
      securityDeposit: Yup.string().required('Security Deposit is required'),
      duration: Yup.string().test('duration-required', 'Duration is required', function (value) {
        if (this.parent.securityDeposit) {
          return value && value.length > 0;
        }
        return true;
      }),
      areaName: Yup.string().required('Area Name is required'),
      areaSize: Yup.string().test('areaSize-required', 'Area Size is required', function (value) {
        if (this.parent.areaName) {
          return value && value.length > 0;
        }
        return true;
      }),

      noOfRoom: Yup.number().required(' No. of Room is required'),
      nearByLandMarks: Yup.string().required(' Near By LAndmark is required'),
      description: Yup.string().required(' description is required'),
    }),
    onSubmit: async (values) => {
      console.log("submitted");
      // console.log({ values });

      if (formik.isValid) {
        console.log('Form is valid');
        try {
          let formData = new FormData();

          // Append fields to FormData
          formData.append('ownerId', owner._id);
          formData.append('name', values.pg_name);
          formData.append('category', values.category);
          formData.append('furnished', values.furnished);
          formData.append('numberOfRooms', values.noOfRoom);
          formData.append('Price', values.price);
          formData.append('facilities', JSON.stringify(values.facilities));
          formData.append('availableRooms', values.availableRoom);
          formData.append('description', values.description);
          formData.append('rules', JSON.stringify(values.rules));
          formData.append('nearbyLandmarks', JSON.stringify(values.nearByLandMarks));
          formData.append('city', values.city_name);
          formData.append('type', values.pgType);
          formData.append('parking', values.parking);
          formData.append('RoomType', values.roomType);
          formData.append('ElectricityCharge', values.electricityCharges);
          formData.append('FoodAvailable', JSON.stringify(values.foodAvailable));
          formData.append('FoodChargesInclude', values.foodCharges);
          formData.append('independent', values.independent);
         
          formData.append('numberOfBathrooms', values.noOfBathrooms);
          formData.append('numberOfBalconies', values.noOfBalcony);
          formData.append('extraCharges', values.extraCharges.split(','));
          
          formData.append('area', JSON.stringify([{ name: values.areaName, size: values.areaSize }]));
          formData.append('securityDeposit', JSON.stringify([{ price: values.securityDeposit, duration: values.duration }]));

          // Append images
          for (let i = 0; i < values.images.length; i++) {
            formData.append('images', values.images[i]);
          }

          // Replace '/api/send-otp' with your actual API endpoint
          await axios.post('http://localhost:4500/CreatePg', formData, {
            headers: {
              'Content-Type': 'multipart/form-data',
            },
          }).then((res) => {
            console.log('pg created:', res);
            // localStorage.setItem("token", res.data.token);
            toast.success(res?.data?.data?.message, {
              position: "top-right",
              autoClose: 5000,
              hideProgressBar: false,
              closeOnClick: true,
              pauseOnHover: true,
              draggable: true,
              progress: undefined,
              theme: "light",
            });
            setTimeout(() => {
              navigate("/ownerDashboard/Profile");
            }, 2000);
          });
          // Handle successful form submission
        } catch (error) {
          console.error('Error Registering Form:', error);
          toast.failure("Error Registering Form", {
            position: "top-right",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            theme: "light",
          });
        }
      } else {
        console.log('Form is not valid');
        console.log('Errors:', formik.errors);
        console.log('Touched:', formik.touched);
      }
    },

  });


  const [isModalOpen, setIsModalOpen] = useState(false); // for adding facility

  const handleNext = () => {
    formik.validateForm().then((errors) => {
      const stepErrors = getStepErrors(errors, currentStep);
      if (Object.keys(stepErrors).length === 0) {
        setCurrentStep((prevStep) => prevStep + 1);
      } else {
        alert('Form validation failed. Please fill in all fields.');
        console.log({ stepErrors });
      }
    });
  };

  const getStepErrors = (errors, step) => {
    const stepFieldNames = getFieldNamesForStep(step);
    return Object.keys(errors).reduce((stepErrors, fieldName) => {
      if (stepFieldNames.includes(fieldName)) {
        stepErrors[fieldName] = errors[fieldName];
      }
      return stepErrors;
    }, {});
  };

  const getFieldNamesForStep = (step) => {
    switch (step) {
      case 1:
        return ['city_name', 'pg_name', 'pgType', 'price', 'noOfRoom', 'duration', 'areaName', 'areaSize', 'securityDeposit'];
      case 2:
        return ['nearByLandmarks', 'areaSize'];
      // Add cases for other steps as needed
      default:
        return [];
    }
  };



  const handlePrevious = () => {
    setCurrentStep((prevStep) => prevStep - 1);
    formik.setTouched({});
    formik.setErrors({});
    formik.setValues({});
  };
  // for image section

  const isImageValid = (file) => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.src = URL.createObjectURL(file);

      img.onload = () => {
        if (img.width <= 500 && img.height <= 400) {
          resolve(file);
        } else {
          alert('Image dimensions must be less than or equal to 500x400 pixels.')
        }
      };
    });
  };

  const handleImageChange = async (e) => {
    const files = e.target.files;

    try {
      const validImages = await Promise.all(Array.from(files).map(isImageValid));
      formik.setValues({ ...formik.values, images: validImages });
    } catch (error) {
      // Handle the error (e.g., show an alert)
      console.error('Invalid image:', error);
    }
  };

  const updateDescription = (event) => {
    formik.setFieldValue('description', event.currentTarget.value);
  };


  const openModal = () => {
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };


  const handleFacilitySelection = (facility) => {
    console.log({ facility });

    // Ensure formik.values.facilities is an array
    const currentFacilities = formik.values.facilities ?? [];

    // Use includes only if currentFacilities is an array
    const isFacilitySelected = Array.isArray(currentFacilities) && currentFacilities.includes(facility);
    if (isFacilitySelected) {
      formik.setFieldValue(
        'facilities',
        currentFacilities.filter((selectedFacility) => selectedFacility !== facility)
      );
    } else {
      formik.setFieldValue('facilities', [...currentFacilities, facility]);
    }
  };

  return (
    <div className="container-fluid mainDiv">
      <div className="row justify-content-center">
        <div className="col-11 col-sm-9 col-md-7 col-lg-6 col-xl-5 text-center p-0 mt-3 mb-2" style={{ width: '60%' }}>
          <div className="card p-0 px-0 pt-4 pb-0 mt-3 mb-3">

            <h2 id="heading" style={{ paddingTop: "20px" }}>Register Your Property</h2>
            <p >Fill all form field to go to the next step</p>
            <form id="msform" style={{ padding: "20px" }} onSubmit={formik.handleSubmit}>
              {/* progressbar */}
              <div>

                <ul id="progressbar">
                  <li id="account" className={currentStep === 1 ? 'active' : ''}>
                    <strong>Account</strong>
                  </li>
                  <li id="personal" className={currentStep === 2 ? 'active' : ''}>
                    <strong>Personal</strong>
                  </li>
                  <li id="payment" className={currentStep === 3 ? 'active' : ''}>
                    <strong>Image</strong>
                  </li>
                  <li id="confirm" className={currentStep === 4 ? 'active' : ''}>
                    <strong>Finish</strong>
                  </li>
                </ul>
                <CustomProgressBar currentStep={currentStep} steps={steps} />

                <br />
                <br />
              </div>




              {/* 1st page */}
              {currentStep === 1 && (
                <fieldset>
                  <div className="form-card">
                    <div className="row">
                      <div className="col-7">
                        <h2 className="fs-title">Account Information:</h2>
                      </div>
                      <div className="col-5">
                        <h2 className="steps">Step 1 - 4</h2>
                      </div>
                    </div>
                    <label className="fieldlabels">City Name: <span style={{ color: "red" }}>*</span></label>
                    <input
                      type="text"
                      name="city_name"
                      placeholder="City Name"
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      value={formik.values.city_name}
                    />
                    {formik.touched.city_name && formik.errors.city_name ? (
                      <div className="text-danger">{formik.errors.city_name}</div>
                    ) : null}
                    {/* pg name */}
                    <label className="fieldlabels">Pg Name: <span style={{ color: "red" }}>*</span></label>
                    <input
                      type="text"
                      name="pg_name"
                      placeholder="Pg Name"
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      value={formik.values.pg_name}
                    />
                    {formik.touched.pg_name && formik.errors.pg_name ? (
                      <div className="text-danger">{formik.errors.pg_name}</div>
                    ) : null}
                    {/* pg type */}
                    <div className="row mb-2">
                      <p style={{ fontSize: "15px" }}>Pg Type:<span style={{ color: "red" }}>*</span></p>
                      <div className="col-md-6">
                        <button
                          type="button"
                          className={`btn ${formik.values.pgType === 'pg' ? 'btn-outline-success' : 'btn-outline-dark'}  m-2`}
                          onClick={() => formik.setFieldValue('pgType', 'pg')}
                          style={{ borderRadius: "20px" }}
                        >
                          PG
                        </button>

                        <button
                          type="button"
                          className={`btn ${formik.values.pgType === 'hostel' ? 'btn-outline-success' : 'btn-outline-dark'} m-2 `}
                          onClick={() => formik.setFieldValue('pgType', 'hostel')}
                          style={{ borderRadius: "20px" }}
                        >
                          Hostel
                        </button>
                      </div>
                      {formik.touched.pgType && formik.errors.pgType ? (
                        <div className="text-danger ">{formik.errors.pgType}</div>
                      ) : null}
                    </div>

                    {/* price */}
                    <label className="fieldlabels">Price(in ₹): <span style={{ color: "red" }}>*</span></label>
                    <input
                      type="text"
                      name="price"
                      placeholder="Price"
                      onChange={(e) => {
                        const numericValue = e.target.value.replace(/[^0-9]/g, '');
                        formik.handleChange({
                          target: {
                            name: e.target.name,
                            value: numericValue,
                          },
                        });
                      }}
                      onBlur={formik.handleBlur}
                      value={formik.values.price}
                      pattern="[0-9]*"
                    />
                    {formik.touched.price && formik.errors.price ? (
                      <div className="text-danger ">{formik.errors.price}</div>
                    ) : null}



                    {/* updated */}
                    <div className="row mb-2 ">
                      <p style={{ fontSize: "15px" }}> Security Deposit:<span style={{ color: "red" }}>*</span></p>
                      <div className="col-md-10 ">
                        {[2000, 3000, 4000, 5000].map((depositOption, index) => (
                          <button
                            key={index}
                            type="button"
                            className={`btn ${formik.values.securityDeposit === depositOption.toString()
                              ? 'btn-outline-success'
                              : 'btn-outline-dark'
                              } m-2 `}
                            onClick={() => {
                              formik.setValues({ ...formik.values, securityDeposit: depositOption.toString(), duration: '' });
                            }}
                            style={{ borderRadius: '20px' }}
                          >
                            ₹ {depositOption}
                          </button>
                        ))}
                      </div>
                    </div>


                    {/* updated */}
                    {formik.values.securityDeposit && (
                      <div className="row mb-2 gap-2">
                        <p style={{ fontSize: "15px" }}> Duration:<span style={{ color: "red" }}>*</span></p>
                        <div className="col-md-12">
                          {[2, 3, 4, 6].map((durationOption, index) => (
                            <button
                              key={index}
                              type="button"
                              className={`btn ${formik.values.duration === durationOption.toString() ? 'btn-outline-success' : 'btn-outline-dark'
                                } m-2`}
                              onClick={() => formik.setValues({ ...formik.values, duration: durationOption.toString() })}
                              style={{ borderRadius: '20px' }}
                            >
                              {durationOption} months
                            </button>
                          ))}
                        </div>
                      </div>
                    )}


                    <label className="fieldlabels">
                      Area Name:<span style={{ color: "red" }}>*</span>
                    </label>
                    <select
                      name="areaName"
                      onChange={(e) => {
                        formik.handleChange(e);

                        formik.setFieldValue('areaSize', '');
                      }}
                      value={formik.values.areaName}
                      onBlur={formik.handleBlur}
                      required
                    >
                      <option value="" disabled selected hidden>
                        Area Name
                      </option>
                      <option value="ballupur">ballupur</option>
                      {/* Add other options here */}
                    </select>
                    {formik.touched.areaName && formik.errors.areaName ? (
                      <div className="text-danger">{formik.errors.areaName}</div>
                    ) : null}

                    {/* Display Area Size Section */}
                    {formik.values.areaName && (
                      <div>
                        <label className="fieldlabels">
                          Area Size (sq.ft): <span style={{ color: "red" }}>*</span>
                        </label>
                        <input
                          type="text"
                          name="areaSize"
                          value={formik.values.areaSize}
                          onChange={(e) => {
                            const numericValue = e.target.value.replace(/[^0-9]/g, ''); // Remove non-numeric characters
                            formik.handleChange({
                              target: {
                                name: e.target.name,
                                value: numericValue,
                              },
                            });
                          }}
                          onBlur={formik.handleBlur}
                          required
                        />
                        {formik.touched.areaSize && formik.errors.areaSize ? (
                          <div className="text-danger">{formik.errors.areaSize}</div>
                        ) : null}
                      </div>
                    )}

                    {/* no of rooms */}


                    <div className="row mb-1">
                      <p style={{ fontSize: "15px" }}>No of rooms:<span style={{ color: "red" }}>*</span></p>
                      <div className="col-md-10">
                        {[1, 2, 3, 4, 5, 6].map((roomOption, index) => (
                          <button
                            key={index}
                            type="button"
                            className={`btn ${formik.values.noOfRoom === roomOption.toString() ? 'btn-outline-success' : 'btn-outline-dark'
                              } m-2`}
                            onClick={() => formik.setFieldValue('noOfRoom', roomOption.toString())}
                            style={{ borderRadius: "20px" }}
                          >
                            {roomOption}
                          </button>
                        ))}
                      </div>
                      {formik.touched.noOfRoom && formik.errors.noOfRoom ? (
                        <div className="text-danger ">{formik.errors.noOfRoom}</div>
                      ) : null}
                    </div>


                  </div>
                  <input
                    type="button"
                    name="next"
                    className="next action-button"
                    value="Next"
                    onClick={handleNext}
                  />
                </fieldset>
              )}

              {/* ***************************************second page********************************************** */}

              {currentStep === 2 && (
                <fieldset>
                  <div className="form-card">
                    <div className="row">
                      <div className="col-7">
                        <h2 className="fs-title">Personal Information:</h2>
                      </div>
                      <div className="col-5">
                        <h2 className="steps">Step 2 - 4</h2>
                      </div>
                    </div>

                    {/* category */}
                    <div className="row mb-2">
                      <p style={{ fontSize: "15px" }}>Category:<span style={{ color: "red" }}>*</span></p>
                      <div className="col-md-8">
                        <button
                          type="button"
                          className={`btn ${formik.values.category === 'girls' ? 'btn-outline-success' : 'btn-outline-dark'} m-2`}
                          onClick={() => formik.setFieldValue('category', 'girls')}
                          style={{ borderRadius: "20px" }}
                        >
                          Girls
                        </button>

                        <button
                          type="button"
                          className={`btn ${formik.values.category === 'boys' ? 'btn-outline-success' : 'btn-outline-dark'} m-2`}
                          onClick={() => formik.setFieldValue('category', 'boys')}
                          style={{ borderRadius: "20px" }}
                        >
                          Boys
                        </button>
                      </div>
                      {formik.touched.category && formik.errors.category ? (
                        <div className="text-danger ">{formik.errors.category}</div>
                      ) : null}
                    </div>
                    {/* fusrnished status */}


                    {/* updated */}

                    <div className="row mb-2">
                      <div className="col-md-12">
                        <p style={{ fontSize: "15px" }}>Furnished:<span style={{ color: "red" }}>*</span></p>
                        {['furnished', 'semi-furnished', 'unfurnished'].map((furnishingOption, index) => (
                          <button
                            key={index}
                            type="button"
                            className={`btn ${formik.values.furnished === furnishingOption ? 'btn-outline-success' : 'btn-outline-dark'
                              } m-2`}
                            onClick={() => formik.setValues({ ...formik.values, furnished: furnishingOption })}
                            style={{ borderRadius: '20px' }}
                          >
                            {furnishingOption.charAt(0).toUpperCase() + furnishingOption.slice(1)}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Room type */}


                    {/* updated */}
                    <div className="row mb-2">
                      <div className="col-md-12">
                        <p style={{ fontSize: "15px" }}>Room Type:<span style={{ color: "red" }}>*</span></p>
                        {['shairing', 'private', 'double', 'tripple'].map((type, index) => (
                          <button
                            key={index}
                            type="button"
                            className={`btn ${formik.values.roomType === type ? 'btn-outline-success' : 'btn-outline-dark'
                              } m-2`}
                            onClick={() => formik.setValues({ ...formik.values, roomType: type })}
                            style={{ borderRadius: '20px' }}
                          >
                            {type.charAt(0).toUpperCase() + type.slice(1)}
                          </button>
                        ))}
                      </div>
                    </div>


                    {/* Electricity Charges */}
                    <div className="row mb-2">
                      <p style={{ fontSize: "15px" }}>Electricity Charges:<span style={{ color: "red" }}>*</span></p>
                      <div className="col-md-6">
                        <button
                          type="button"
                          className={`btn ${formik.values.electricityCharges === 'yes' ? 'btn-outline-success' : 'btn-outline-dark'} m-2`}
                          onClick={() => formik.setFieldValue('electricityCharges', 'yes')}
                          style={{ borderRadius: "20px" }}
                        >
                          Yes
                        </button>

                        <button
                          type="button"
                          className={`btn ${formik.values.electricityCharges === 'no' ? 'btn-outline-success' : 'btn-outline-dark'} m-2`}
                          onClick={() => formik.setFieldValue('electricityCharges', 'no')}
                          style={{ borderRadius: "20px" }}
                        >
                          No
                        </button>
                      </div>
                      {formik.touched.electricityCharges && formik.errors.electricityCharges ? (
                        <div className="text-danger ">{formik.errors.electricityCharges}</div>
                      ) : null}
                    </div>


                    {/* Food Available */}

                    <div className="row mb-2">
                      <div className="col-md-12">
                        <p style={{ fontSize: "15px" }}>Food Availability:<span style={{ color: "red" }}>*</span></p>
                        {['breakfast', 'lunch', 'dinner'].map((foodOption, index) => (
                          <button
                            key={index}
                            type="button"
                            className={`btn ${formik.values.foodAvailable
                              ? formik.values.foodAvailable.includes(foodOption)
                                ? 'btn-outline-success'
                                : 'btn-outline-dark'
                              : 'btn-outline-dark'
                              } m-2`}
                            onClick={() => {
                              const isSelected = formik.values.foodAvailable
                                ? formik.values.foodAvailable.includes(foodOption)
                                : false;
                              formik.setValues((prevValues) => ({
                                ...formik.values,
                                foodAvailable: isSelected
                                  ? prevValues.foodAvailable.filter((type) => type !== foodOption)
                                  : [...(prevValues.foodAvailable || []), foodOption],
                              }));
                            }}
                            style={{ borderRadius: '20px' }}
                          >
                            {foodOption.charAt(0).toUpperCase() + foodOption.slice(1)}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Food Charges avaialable  */}
                    {formik.values.foodAvailable && (
                      <div className="row mb-2">
                        <p style={{ fontSize: "15px" }}>Food Charges Included:<span style={{ color: "red" }}>*</span></p>
                        <div className="col-md-6">
                          <button
                            type="button"
                            className={`btn ${formik.values.foodCharges === 'yes' ? 'btn-outline-success' : 'btn-outline-dark'} m-2`}
                            onClick={() => formik.setFieldValue('foodCharges', 'yes')}
                            style={{ borderRadius: "20px" }}
                          >
                            Yes
                          </button>

                          <button
                            type="button"
                            className={`btn ${formik.values.foodCharges === 'no' ? 'btn-outline-success' : 'btn-outline-dark'} m-2`}
                            onClick={() => formik.setFieldValue('foodCharges', 'no')}
                            style={{ borderRadius: "20px" }}
                          >
                            No
                          </button>
                        </div>
                        {formik.touched.foodCharges && formik.errors.foodCharges ? (
                          <div className="text-danger ">{formik.errors.foodCharges}</div>
                        ) : null}
                      </div>
                    )}


                    {/* parking */}
                    <div className="row mb-2">
                      <p style={{ fontSize: "15px" }}>Parking:<span style={{ color: "red" }}>*</span></p>
                      <div className="col-md-6">
                        <button
                          type="button"
                          className={`btn ${formik.values.parking === 'yes' ? 'btn-outline-success' : 'btn-outline-dark'} m-2`}
                          onClick={() => formik.setFieldValue('parking', 'yes')}
                          style={{ borderRadius: "20px" }}
                        >
                          Yes
                        </button>

                        <button
                          type="button"
                          className={`btn ${formik.values.parking === 'no' ? 'btn-outline-success' : 'btn-outline-dark'} m-2`}
                          onClick={() => formik.setFieldValue('parking', 'no')}
                          style={{ borderRadius: "20px" }}
                        >
                          No
                        </button>
                      </div>
                      {formik.touched.parking && formik.errors.parking ? (
                        <div className="text-danger ">{formik.errors.parking}</div>
                      ) : null}
                    </div>
                    {/* no of bathrooms */}


                    {/* updated */}
                    <div className="row mb-1">
                      <p style={{ fontSize: "15px" }}>No of bathrooms:<span style={{ color: "red" }}>*</span></p>
                      <div className="col-md-12">
                        {[1, 2, 3, 4, 5, '5+'].map((bathroomOption, index) => (
                          <button
                            key={index}
                            type="button"
                            className={`btn ${formik.values.noOfBathrooms === bathroomOption
                              ? 'btn-outline-success'
                              : 'btn-outline-dark'
                              }  m-2`}
                            onClick={() => formik.setFieldValue('noOfBathrooms', bathroomOption)}
                            style={{ borderRadius: "20px" }}
                          >
                            {bathroomOption}
                          </button>
                        ))}
                      </div>
                      {formik.touched.noOfBathrooms && formik.errors.noOfBathrooms ? (
                        <div className="text-danger ">{formik.errors.noOfBathrooms}</div>
                      ) : null}
                    </div>

                    {/* no of balcony */}




                    {/* updated */}
                    <div className="row mb-1">
                      <p style={{ fontSize: "15px" }}>No of Balcony:<span style={{ color: "red" }}>*</span></p>
                      <div className="col-md-12">
                        {['1', '2', '3', '4', '5', '5+'].map((balconyOption, index) => (
                          <button
                            key={index}
                            type="button"
                            className={`btn ${formik.values.noOfBalcony === balconyOption
                              ? 'btn-outline-success'
                              : 'btn-outline-dark'
                              }  m-2`}
                            onClick={() => formik.setFieldValue('noOfBalcony', balconyOption)}
                            style={{ borderRadius: "20px" }}
                          >
                            {balconyOption}
                          </button>
                        ))}
                      </div>
                      {formik.touched.noOfBalcony && formik.errors.noOfBalcony ? (
                        <div className="text-danger ">{formik.errors.noOfBalcony}</div>
                      ) : null}
                    </div>


                    {/* independent */}
                    <div className="row mb-2">
                      <p style={{ fontSize: "15px" }}>Independent:<span style={{ color: "red" }}>*</span></p>
                      <div className="col-md-6">
                        <button
                          type="button"
                          className={`btn ${formik.values.independent === 'yes' ? 'btn-outline-success' : 'btn-outline-dark'} m-2`}
                          onClick={() => formik.setFieldValue('independent', 'yes')}
                          style={{ borderRadius: "20px" }}
                        >
                          Yes
                        </button>

                        <button
                          type="button"
                          className={`btn ${formik.values.independent === 'no' ? 'btn-outline-success' : 'btn-outline-dark'} `}
                          onClick={() => formik.setFieldValue('independent', 'no')}
                          style={{ borderRadius: "20px" }}
                        >
                          No
                        </button>
                      </div>
                      {formik.touched.independent && formik.errors.independent ? (
                        <div className="text-danger ">{formik.errors.independent}</div>
                      ) : null}
                    </div>
                    {/* next */}
                    <input
                      type="button"
                      name="next"
                      className="next action-button"
                      value="Next"
                      onClick={handleNext}
                    />
                    <input
                      type="button"
                      name="previous"
                      className="previous action-button-previous "
                      value="Previous"
                      onClick={handlePrevious}
                    />
                  </div>
                </fieldset>
              )}
              {currentStep === 3 && (
                <fieldset>
                  <div className="form-card">
                    <div className="row">
                      <div className="col-7">
                        <h2 className="fs-title">Image Upload:</h2>
                      </div>
                      <div className="col-5">
                        <h2 className="steps">Step 3 - 4</h2>
                      </div>

                      {/* image uploads */}
                    </div>
                    <label className="fieldlabels">Upload Your Photo:</label>
                    <input type="file" name="images" accept="image/*" multiple onChange={handleImageChange} />

                    {/* Preview Section */}


                    <div id="carouselExampleCaptions" className="carousel slide" data-bs-ride="carousel" style={{ maxWidth: '400px', maxHeight: "200px", margin: 'auto' }}>
                      <div className="carousel-indicators">
                        {formik.values.images &&
                          formik.values.images.map((_, index) => (
                            <button key={index} type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to={index} className={index === 0 ? 'active' : ''} aria-current={index === 0} aria-label={`Slide ${index + 1}`}></button>
                          ))}
                      </div>

                      <div className="carousel-inner" style={{ borderRadius: "10px" }}>
                        {formik.values.images &&
                          formik.values.images.map((image, index) => (
                            <div className={`carousel-item ${index === 0 ? 'active' : ''} `} key={index} >
                              <img src={URL.createObjectURL(image)} alt={`Preview ${index}`} className="d-block w-100 h-50" style={{ maxWidth: '400px', maxHeight: "200px", margin: 'auto' }} />

                            </div>
                          ))}
                      </div>

                      <button className="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
                        <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span className="visually-hidden">Previous</span>
                      </button>
                      <button className="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
                        <span className="carousel-control-next-icon" aria-hidden="true"></span>
                        <span className="visually-hidden">Next</span>
                      </button>
                    </div>



                    {/* Available Rooms */}

                    <div className="row mb-1">
                      <p style={{ fontSize: "15px" }}>Available Rooms:<span style={{ color: "red" }}>*</span></p>
                      <div className="col-md-12">
                        {['1', '2', '3', '4', '5', '5+'].map((roomOption, index) => (
                          <button
                            key={index}
                            type="button"
                            className={`btn ${formik.values.availableRoom === roomOption ? 'btn-outline-success' : 'btn-outline-dark'} m-2`}
                            onClick={() => formik.setFieldValue('availableRoom', roomOption)}
                            style={{ borderRadius: "20px" }}
                          >
                            {roomOption}
                          </button>
                        ))}
                      </div>
                      {formik.touched.availableRoom && formik.errors.availableRoom ? (
                        <div className="text-danger ">{formik.errors.availableRoom}</div>
                      ) : null}
                    </div>


                    {/* nearbyLandmarks */}
                    <label className="fieldlabels">nearbyLandmark: <span style={{ color: "red" }}>*</span></label>
                    <input
                      type="text"
                      name="nearByLandMarks"
                      placeholder="NearBy Landmarks"
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      value={formik.values.nearByLandMarks}
                    />
                    {formik.touched.nearByLandMarks && formik.errors.nearByLandMarks ? (
                      <div className="text-danger">{formik.errors.nearByLandMarks}</div>
                    ) : null}

                    {/* Rules */}

                    {/* updated */}
                    <div className="row mb-2">
                      <div className="col-md-12">
                        <p style={{ fontSize: "15px" }}>Rules:<span style={{ color: "red" }}>*</span></p>
                        {['No pets', 'No Smoking', 'Girls not allowed'].map((ruleOption, index) => (
                          <button
                            key={index}
                            type="button"
                            className={`btn ${formik.values.rules
                              ? formik.values.rules.includes(ruleOption)
                                ? 'btn-outline-success'
                                : 'btn-outline-dark'
                              : 'btn-outline-dark'
                              } m-2`}
                            onClick={() => {
                              const isSelected = formik.values.rules
                                ? formik.values.rules.includes(ruleOption)
                                : false;
                              formik.setValues((prevValues) => ({
                                ...formik.values,
                                rules: isSelected
                                  ? prevValues.rules.filter((type) => type !== ruleOption)
                                  : [...(prevValues.rules || []), ruleOption],
                              }));
                            }}
                            style={{ borderRadius: '20px' }}
                          >
                            {ruleOption}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* facility */}
                    <div>
                      <label className="fieldlabels">Facilities: <span style={{ color: "red" }}>*</span></label>
                      <div>
                        Selected Facilities:{' '}
                        {formik.values.facilities && Array.from(formik.values.facilities).map((facility) => (
                          <span key={facility} style={{ color: "green" }}>{facility}, </span>
                        ))}
                      </div>
                      <h6 style={{ color: "red", fontFamily: "fantasy", fontWeight: "bold" }} type="button" onClick={openModal}>
                        + Add Facility
                      </h6>



                      <FacilityModal
                        isOpen={isModalOpen}
                        onClose={closeModal}
                        onSelectFacility={handleFacilitySelection}
                        selectedFacilities={formik.values.facilities}
                        formik={formik}
                      />
                    </div>

                    {/* extra charges */}
                    <label className="fieldlabels">Extra Charges: <span style={{ color: "red" }}>*</span></label>
                    <input
                      type="text"
                      name="extraCharges"
                      placeholder="NearBy Landmarks"
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      value={formik.values.extraCharges}
                    />
                    {formik.touched.extraCharges && formik.errors.extraCharges ? (
                      <div className="text-danger">{formik.errors.extraCharges}</div>
                    ) : null}

                    {/* description */}
                    <label className="fieldlabels">Description:</label>
                    <textarea
                      name="description"
                      value={formik.values.description}
                      onChange={updateDescription}
                      style={{ height: 'auto', width: '100%' }}
                      rows={4} // Initial rows
                    />
                    {formik.touched.description && formik.errors.description ? (
                      <div className="error-message">{formik.errors.description}</div>
                    ) : null}

                    {/* Word count display */}
                    <div style={{ marginTop: '10px' }}>Word Count: {formik.values.description?.length} out of 1000</div>
                  </div>
                  <input
                    type="button"
                    name="next"
                    className="next action-button"
                    value="Submit"
                    onClick={formik.handleSubmit}
                  />
                  <ToastContainer />

                  <input
                    type="button"
                    name="previous"
                    className="previous action-button-previous"
                    value="Previous"
                    onClick={handlePrevious}
                  />
                </fieldset>
              )}
              {currentStep === 4 && (
                <fieldset>
                  <div className="form-card">
                    <div className="row">
                      <div className="col-7">
                        <h2 className="fs-title">Finish:</h2>
                      </div>
                      <div className="col-5">
                        <h2 className="steps">Step 4 - 4</h2>
                      </div>
                    </div>
                    <br />
                    <br />
                    <h2 className="purple-text text-center">
                      <strong>SUCCESS !</strong>
                    </h2>
                    <br />
                    <div className="row justify-content-center">
                      <div className="col-3">
                        <img
                          src="https://i.imgur.com/GwStPmg.png"
                          className="fit-image"
                          alt="success"
                        />
                      </div>
                    </div>
                    <br />
                    <br />
                    <div className="row justify-content-center">
                      <div className="col-7 text-center">
                        <h5 className="purple-text text-center">
                          You Have Successfully Signed Up
                        </h5>
                      </div>
                    </div>
                  </div>
                </fieldset>
              )}

            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BasicDetail;