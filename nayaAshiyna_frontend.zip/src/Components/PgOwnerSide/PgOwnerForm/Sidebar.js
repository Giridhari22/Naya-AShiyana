import React from 'react'
import "./Form1.css"

function Sidebar() {
  return (
    <div>
              <div class="left-heading">
             
              <h4>  <img src="assets/img/Home.jpeg" alt="" title="" style={{ width: "100px", height: "50px" , borderRadius:"50%" }} /> Naya<span style={{color:'#71c55d'}}>Ashiyana</span> </h4>
              </div>
              <div class="steps-content">
                <h3>Fill <span class="step-number">Details</span></h3>
                <p class="step-number-content active">Here you have to fill basic detail of your property.</p>
                <p class="step-number-content d-none"> 2 you are second.</p>
                <p class="step-number-content d-none"> 3 Help companies get to know you better by telling then about
                  your past experiences.</p>
                <p class="step-number-content d-none"> 4 Add your profile picture and let companies find youy fast.
                </p>
              </div>
              <ul class="progress-bar">
                <li class="active"> 5 Basic Detail</li>
                <li>
                  <p> 6 Организация</p>
                </li>
                <li>
                  <p> 7 Фотография</p>
                </li>
                <li>
                  <p> 8 Подтверждение</p>
                </li>
                <li>
                  <p> 9 Гарантийное письмо</p>
                </li>
              </ul>



            </div>

  )
}

export default Sidebar