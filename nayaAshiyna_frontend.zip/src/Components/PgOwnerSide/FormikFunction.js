import * as Yup from 'yup';

const validationSchema = Yup.object().shape({
    first_name: Yup.string().required('First Name is required'),
    last_name: Yup.string().required('Last Name is required'),
    email: Yup.string().email('Invalid email').required('Email is required'),
    phone: Yup.string().required('Phone is required'),
    date_of_birth: Yup.date().required('Date of Birth is required'),
    city: Yup.string().required('City is required'),
    state: Yup.string().required('State is required'),
    zip: Yup.string().required('Zip Code is required'),
    company_name: Yup.string().required('Company/Property Name is required'),
    currency: Yup.string().required('Select Currency is required'),
    employment_type: Yup.string().required('Employment Type is required'),
    description: Yup.string().required('Description is required'),
  });

  export default validationSchema;