import React, { useState } from 'react';
import "./FreeSubs.css";
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import jwt_decode from "jwt-decode";

function Subs() {
    const navigate = useNavigate()
    // const [owner , setOwner] = useState(JSON.parse(localStorage.getItem("owner")));


    const queryParams = new URLSearchParams(window.location.search);

    const token = queryParams.get('token');
    let decodeToken
    if (token) {
        decodeToken = jwt_decode(token);
        console.log("decode owner", decodeToken)
    }
    if (token) {
        localStorage.setItem("token", token)
    }
    if (decodeToken) {

        localStorage.setItem('owner', JSON.stringify({ name: decodeToken.owner.name, googleId: decodeToken.owner.googleId, email: decodeToken.owner.email, id: decodeToken.owner._id }));
    }
    const handleOpenRazorpay = (data) => {
        const options = {
            key: 'rzp_test_IwVO9h2RjG7jkB',
            amount: Number(data.amount) * 100,
            currency: 'INR',
            name: "NayaAshiyana",
            description: "Payment for NayaAshiyana",
            order_id: data.id,
            handler: function (response) {
                console.log(response, "50")
                axios.post("http://localhost:4500/verifyOrder", { response: response })
                    .then(res => {
                        console.log('res', res, '53')
                        navigate("/OwnerDashboard/Form1")
                    })
                    .catch((err) => {
                        console.log(err)
                    })
            }

        }

        // naya razorpay hame window k andar milega qki hamne index.html m razorpay ka script dal diya hai
        var rzp = new window.Razorpay(options);
        rzp.open()
    }

    const handlePayment = (amount) => {
        const owner = JSON.parse(localStorage.getItem("owner"))
        console.log({ owner })
        console.log("amount", amount)
        const _data = { amount: amount, ownerId: owner._id }
        console.log("data =>", _data)
        axios.post("http://localhost:4500/sendOrder", _data)
            .then(res => {
                console.log('order', res.data);
                handleOpenRazorpay(res.data.data)
            })
            .catch(err => {
                console.log("error", err)
            })
    }
    return (
        <div>
            <div class="container" >
                <h5 class="text-center pricing-table-subtitle">PRICING PLAN</h5>
                <h1 class="text-center pricing-table-title">Subscription Table</h1>
                <div class="row pricing-table-row justify-content-end" style={{ borderRadius: "20px" }}>
                    <div class="col-md-4">
                        <div class="card pricing-card pricing-plan-basic" style={{ borderRadius: "20px" }}>
                            <div class="card-body" >
                                <i class="mdi mdi-cube-outline pricing-plan-icon" ></i>
                                <center>
                                    <div className='pointerss'>
                                        <p class="pricing-plan-title " style={{ color: "white" }}>Basic</p>
                                    </div>
                                </center>
                                <h3 class="pricing-plan-cost ml-auto">FREE</h3>
                                <h5> Standard Visibility</h5>
                                <h5> Upto 3 Enquiries</h5>

                                <ul class="pricing-plan-features">
                                    <li>
                                        <span class="feature-text">Matching Leads</span>
                                        <span class="feature-icon cross ">&#10007; No </span>
                                    </li>
                                    <li>
                                        <span class="feature-text">Automated Video Listing</span>
                                        <span class="feature-icon cross ">&#10007; No </span>
                                    </li>
                                    <li>
                                        <span class="feature-text">Free Rent Agreement worth Rs 500*</span>
                                        <span class="feature-icon cross">&#10007; No</span>
                                    </li>
                                    <li>
                                        <span class="feature-text">Relationship Manager (RM)</span>
                                        <span class="feature-icon cross">&#10007; No</span>
                                    </li>
                                    <li>
                                        <span class="feature-text">Assisted Listing</span>
                                        <span class="feature-icon cross">&#10007; No</span>
                                    </li>

                                    <li>
                                        <span class="feature-text">Advertise Property on Multiple Platforms</span>
                                        <span class="feature-icon cross">&#10007; No</span>
                                    </li>
                                    <li>
                                        <span class="feature-text">Personal Field Assistant</span>
                                        <span class="feature-icon cross">&#10007; No</span>
                                    </li>
                                    <li>
                                        <span class="feature-text">Showing Property on Your Behalf</span>
                                        <span class="feature-icon cross">&#10007; No</span>
                                    </li>
                                    <li>
                                        <span class="feature-text">Privacy of your Phone Number</span>
                                        <span class="feature-icon cross">&#10007; No</span>
                                    </li>

                                    <li>
                                        <span class="feature-text">Get Tenants 3X Faster</span>
                                        <span class="feature-icon cross">&#10007; No</span>
                                    </li>
                                    <li>
                                        <span class="feature-text">Hassle Free Property Management</span>
                                        <span class="feature-icon cross">&#10007; No</span>
                                    </li>
                                    <li>
                                        <span class="feature-text">Ontime Rent Collection through App</span>
                                        <span class="feature-icon cross">&#10007; No</span>
                                    </li>
                                    <li>
                                        <span class="feature-text">Quarterly Property Inspection Report</span>
                                        <span class="feature-icon cross">&#10007; No</span>
                                    </li>

                                    <li>
                                        <span class="feature-text">Complete Leasing Management</span>
                                        <span class="feature-icon cross">&#10007; No</span>
                                    </li>
                                    <li>
                                        <span class="feature-text">Guaranteed Tenants or No Propery Management Fees</span>
                                        <span class="feature-icon cross">&#10007; No</span>
                                    </li>

                                </ul>
                                <a class="btn pricing-plan-purchase-btn" onClick={(e) => { navigate("/OwnerDashboard/Form1") }}>Free</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class=" card pricing-card pricing-card-highlighted  pricing-plan-pro" style={{ backgroundColor: "#59AEFB ", borderRadius: "20px" }}>
                            <div class="card-body" style={{ backgroundColor: "#59AEFB ", borderRadius: "20px" }}>
                                <i class="mdi mdi-trophy pricing-plan-icon" style={{ color: "silver" }}></i>
                                <center>
                                    <div className='pointers'>
                                        <p class="pricing-plan-title">Landlord Prime </p>
                                    </div>
                                </center>
                                <h3 class="pricing-plan-cost ml-auto">₹2999</h3>
                                <h5 >10X More Visibility</h5>
                                <h5 >Unlimited Enquiries</h5>
                                <h5 >20 Matching Leads</h5>

                                <ul class="pricing-plan-features">
                                    <li>
                                        <span class="feature-text">Automated Video Listing</span>
                                        <span class="feature-icon tick ">&#10003; Yes</span>
                                    </li>
                                    <li>
                                        <span class="feature-text">Free Rent Agreement worth Rs 500*</span>
                                        <span class="feature-icon tick">&#10003; Yes</span>
                                    </li>
                                    <li>
                                        <span class="feature-text">Relationship Manager (RM)</span>
                                        <span class="feature-icon tick">&#10003; Yes</span>
                                    </li>
                                    <li>
                                        <span class="feature-text">Assisted Listing</span>
                                        <span class="feature-icon tick">&#10003; Yes</span>
                                    </li>

                                    <li>
                                        <span class="feature-text">Advertise Property on Multiple Platforms</span>
                                        <span class="feature-icon cross">&#10007; No</span>
                                    </li>
                                    <li>
                                        <span class="feature-text">Personal Field Assistant</span>
                                        <span class="feature-icon cross">&#10007; No</span>
                                    </li>
                                    <li>
                                        <span class="feature-text">Showing Property on Your Behalf</span>
                                        <span class="feature-icon cross">&#10007; No</span>
                                    </li>
                                    <li>
                                        <span class="feature-text">Privacy of your Phone Number</span>
                                        <span class="feature-icon cross">&#10007; No</span>
                                    </li>

                                    <li>
                                        <span class="feature-text">Get Tenants 3X Faster</span>
                                        <span class="feature-icon cross">&#10007; No</span>
                                    </li>
                                    <li>
                                        <span class="feature-text">Hassle Free Property Management</span>
                                        <span class="feature-icon cross">&#10007; No</span>
                                    </li>
                                    <li>
                                        <span class="feature-text">Ontime Rent Collection through App</span>
                                        <span class="feature-icon cross">&#10007; No</span>
                                    </li>
                                    <li>
                                        <span class="feature-text">Quarterly Property Inspection Report</span>
                                        <span class="feature-icon cross">&#10007; No</span>
                                    </li>

                                    <li>
                                        <span class="feature-text">Complete Leasing Management</span>
                                        <span class="feature-icon cross">&#10007; No</span>
                                    </li>
                                    <li>
                                        <span class="feature-text">Guaranteed Tenants or No Propery Management Fees</span>
                                        <span class="feature-icon cross">&#10007; No</span>
                                    </li>

                                </ul>

                                <a href="#!" class="btn pricing-plan-purchase-btn"
                                    onClick={() => { handlePayment(2999) }}
                                >Purchase</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card pricing-card pricing-plan-enterprise" style={{ borderRadius: "20px" }}>

                            <div class="card-body" style={{ backgroundColor: "#0A3864", borderRadius: "20px" }}>
                                <i class="mdi mdi-wallet-giftcard pricing-plan-icon"></i>
                                {/* <center>
                                    <div className='pointer '>
                                        <p class="pricing-plan-title " style={{ color: "white" }}>Landlord Prime Plus</p>
                                    </div>
                                </center> */}
                                <div className="pointer">
                                    <p className="pricing-plan-title" style={{ color: "white" }}>Landlord Prime Plus</p>
                                </div>
                                <h3 class="pricing-plan-cost ml-auto" style={{ color: "white" }} >₹3999</h3>
                                <h5 style={{ color: "White" }}>20X More Visibility</h5>
                                <h5 style={{ color: "White" }}>Unlimited Enquiries</h5>
                                <h5 style={{ color: "White" }}>20 Matching Leads</h5>

                                <ul class="pricing-plan-features">
                                    <li>
                                        <span class="feature-text Third" >Automated Video Listing</span>
                                        <span class="feature-icon tick ">&#10003; Yes</span>
                                    </li>
                                    <li>
                                        <span class="feature-text Third">Free Rent Agreement worth Rs 500*</span>
                                        <span class="feature-icon tick">&#10003; Yes</span>
                                    </li>
                                    <li>
                                        <span class="feature-text Third">Relationship Manager (RM)</span>
                                        <span class="feature-icon tick">&#10003; Yes</span>
                                    </li>
                                    <li>
                                        <span class="feature-text Third">Assisted Listing</span>
                                        <span class="feature-icon tick">&#10003; Yes</span>
                                    </li>

                                    <li>
                                        <span class="feature-text Third">Advertise Property on Multiple Platforms</span>
                                        <span class="feature-icon tick">&#10003; Yes</span>
                                    </li>
                                    <li>
                                        <span class="feature-text Third">Personal Field Assistant</span>
                                        <span class="feature-icon tick">&#10003; Yes</span>
                                    </li>
                                    <li>
                                        <span class="feature-text Third">Showing Property on Your Behalf</span>
                                        <span class="feature-icon tick">&#10003; Yes</span>
                                    </li>
                                    <li>
                                        <span class="feature-text Third">Privacy of your Phone Number</span>
                                        <span class="feature-icon tick">&#10003; Yes</span>
                                    </li>

                                    <li>
                                        <span class="feature-text Third">Get Tenants 3X Faster</span>
                                        <span class="feature-icon tick">&#10003; Yes</span>
                                    </li>
                                    <li>
                                        <span class="feature-text Third">Hassle Free Property Management</span>
                                        <span class="feature-icon tick">&#10003; Yes</span>
                                    </li>
                                    <li>
                                        <span class="feature-text Third">Ontime Rent Collection through App</span>
                                        <span class="feature-icon tick">&#10003; Yes</span>
                                    </li>
                                    <li>
                                        <span class="feature-text Third">Quarterly Property Inspection Report</span>
                                        <span class="feature-icon tick">&#10003; Yes</span>
                                    </li>

                                    <li>
                                        <span class="feature-text Third">Complete Leasing Management</span>
                                        <span class="feature-icon tick">&#10003; Yes</span>
                                    </li>
                                    <li>
                                        <span class="feature-text Third">Guaranteed Tenants or No Propery Management Fees</span>
                                        <span class="feature-icon tick">&#10003; Yes</span>
                                    </li>

                                </ul>
                                <a href="#!" class="btn pricing-plan-purchase-btn"
                                    onClick={() => { handlePayment(3999) }}
                                >Purchase</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Subs

