import React, { useEffect, useState } from 'react';
import { Modal, Button, Carousel, FormControl } from 'react-bootstrap';
import { useNavigate } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';
import './MyListing.css';
import axios from 'axios';

const MyListing = () => {
    const [showModal, setShowModal] = useState(false);
    const [showEditModal, setShowEditModal] = useState(false);

    const [showDeleteModal, setShowDeleteModal] = useState(false);
    const [owner, setOwner] = useState(JSON.parse(localStorage.getItem("owner")));
    const [editedData, setEditedData] = useState(null);
    const [editedField, setEditedField] = useState(null);
    const [datas, setDatas] = useState([])
    const [pgdata, setPgdata] = useState([])
    const [editPgdata, setEditPgdata] = useState([])

    const [ids, setIds] = useState()
    const navigate = useNavigate()
    const [activeIndex, setActiveIndex] = useState(0);




    useEffect(() => {
        const getPgByOwnersId = async () => {
            try {
                const response = await axios.get(`http://localhost:4500/getPgByOwnersId/${owner._id}`);
                console.log("API Response:", response);

                const responseData = response?.data?.data;

                if (responseData) {
                    const dataArray = Array.isArray(responseData) ? responseData : [responseData];
                    setDatas(dataArray);
                    console.log("response", dataArray);
                } else {
                    console.error("Invalid response data. Expected an array or an object.");
                    console.error("Actual response data:", responseData);
                }
            } catch (error) {
                console.error('Error fetching owner details:', error);
            }
        };

        getPgByOwnersId();
    }, [owner._id]);


    // for view modal
    const handleSelect = (selectedIndex) => {
        setActiveIndex(selectedIndex);
    };

    const handleEditClick = (id) => {
        const getEditById = async () => {
            try {
                const response = await axios.get(`http://localhost:4500/getPg/${id}`);
                console.log("API Response for eye:", response);

                const responseData = response?.data?.data;

                if (responseData) {
                    const dataArray = Array.isArray(responseData) ? responseData : [responseData];
                    setEditPgdata(dataArray);
                    console.log("response for eye", dataArray);
                } else {
                    console.error("Invalid response data. Expected an array or an object.");
                    console.error("Actual response data:", responseData);
                }
            } catch (error) {
                console.error('Error fetching owner details:', error);
            }
        };
        getEditById()

        setShowEditModal(true);

    }

    const handleViewClick = (id) => {
        const getPgById = async () => {
            try {
                const response = await axios.get(`http://localhost:4500/getPg/${id}`);
                console.log("API Response for eye:", response);

                const responseData = response?.data?.data;

                if (responseData) {
                    const dataArray = Array.isArray(responseData) ? responseData : [responseData];
                    setPgdata(dataArray);
                    console.log("response for eye", dataArray);
                } else {
                    console.error("Invalid response data. Expected an array or an object.");
                    console.error("Actual response data:", responseData);
                }
            } catch (error) {
                console.error('Error fetching owner details:', error);
            }
        };
        getPgById()

        setShowModal(true);
    };

    const handleCloseModal = () => {
        setShowEditModal(false)
        setShowModal(false);
    };

    const handleDeleteClick = (id) => {
        setIds(id)
        setShowDeleteModal(true);
    };

    const handleCloseDeleteModal = () => {
        setShowDeleteModal(false);
    };

    const handleEdit = (field, value) => {
        // Set the field and its value to editedData state
        setEditedData({ ...editedData, [field]: value });
        setEditedField(field);
    };

    const handleSaveChanges = () => {
        // Handle saving changes, you can send editedData to your backend or update your state
        // Reset editedData and close modal
        setEditedData(null);
        setEditedField(null);
        setShowModal(false);
    };

    const handleDeleteConfirm = () => {
        const deletePG = async () => {
            console.log("id hai", ids)
            console.log("running")
            try {
                const deleteResponse = await axios.delete(`http://localhost:4500/deletePg/${ids}`);
                console.log("API Response for delete:", deleteResponse);

            } catch (error) {
                console.error('Error fetching owner details:', error);

            }
        }
        deletePG()


        setShowDeleteModal(false);
    };

    return (
        <div className="container-xl">
            <div className="table-responsive">

                <div className="table-wrapper">
                    <div className="table-title">
                        <div className="row">
                            <div className="col-sm-4">
                                <h2> Your Pg <b> Listings </b></h2>
                            </div>
                            <div className="col-sm-4">
                                <button className='btn btn-success p-2 ' style={{ width: "200px", fontSize: "20px" }} onClick={() => { navigate("/OwnerDashboard/Form1") }} >Post Property</button>
                            </div>
                            <div className="col-sm-4">
                                <div className="search-box">
                                    <i className="material-icons">&#xE8B6;</i>
                                    <input type="text" className="form-control" placeholder="Search&hellip;" />
                                </div>
                            </div>
                        </div>
                    </div>
                    <table className="table table-striped table-hover table-bordered">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Images</th>
                                <th>Pg Name <i className="fa fa-sort"></i></th>
                                <th>Address</th>
                                <th>City <i className="fa fa-sort"></i></th>
                                <th>Type</th>
                                <th>Price <i className="fa fa-sort"></i></th>
                                <th>Actions</th>
                            </tr>
                        </thead>

                        <tbody>
                            {Array.isArray(datas) && datas.map((pg, index) => (

                                <tr >

                                    <td>1</td>

                                    <td style={{ width: "100px", height: "100px" }}>

                                        <Carousel indicators interval={null} nextIcon={<span className="carousel-arrow">&#9654;</span>} prevIcon={<span className="carousel-arrow">&#9664;</span>}>
                                            {pg.images.map((image, index) => (
                                                <Carousel.Item key={index}>
                                                    <img src={`http://localhost:4500${image}`} alt={`Image ${index}`} className="customer-image" />
                                                </Carousel.Item>
                                            ))}
                                        </Carousel>

                                    </td>
                                    <td className='txt'>{pg?.name}</td>
                                    <td className='txt'>{pg?.area[0]?.name}</td>
                                    <td className='txt'>{pg?.city}</td>
                                    <td className='txt'>{pg?.type}</td>
                                    <td className='txt'>{pg?.Price}</td>

                                    <td>
                                        <a href="#" class="view" title="View" data-toggle="tooltip" onClick={(e) => { handleViewClick(pg._id) }}><i class="fa fa-eye" style={{ fontSize: "20px" }}></i></a>
                                        <a href="#" class="edit" title="Edit" data-toggle="tooltip" onClick={(e) => { handleEditClick(pg._id) }}><i class="fa fa-edit" style={{ fontSize: "20px" }}></i></a>
                                        <a href="#" class="delete" title="Delete" data-toggle="tooltip" onClick={(e) => { handleDeleteClick(pg._id) }}><i class="fa fa-trash-o" style={{ fontSize: "20px" }}></i></a>
                                    </td>
                                </tr>
                            ))}


                        </tbody>
                    </table>



                    {/* modal for view */}

                    <Modal show={showModal} onHide={handleCloseModal} size="lg" dialogClassName="modal-lg">
                        <Modal.Header closeButton>
                            <Modal.Title>Property Details</Modal.Title>
                        </Modal.Header>
                        {Array.isArray(pgdata) && pgdata.map((property, index) => (
                            <Modal.Body key={index} style={{ borderRadius: "20px", width: "100%" }}>
                                <div className="card" style={{ borderRadius: "20px", backgroundColor: "#54B4D3" }}>
                                    <h1 className="card-title text-center text-uppercase" style={{ color: "white" }}>{property.name}</h1>
                                    <Carousel activeIndex={activeIndex} onSelect={handleSelect} >
                                        {property.images.map((image, index) => (
                                            <Carousel.Item key={index} style={{ borderRadius: "20px" }}>
                                                <img
                                                    src={`http://localhost:4500${image}`}
                                                    alt={`Image ${index}`}
                                                    className="d-block w-100 "
                                                    style={{ width: '100%', height: '300px', objectFit: 'cover' }}
                                                />
                                            </Carousel.Item>
                                        ))}
                                    </Carousel>
                                    <div className="card-body">
                                        <div className="row">
                                            <div className="col-md-6 mb-4 p-4 gap-2 shadow " style={{ borderRadius: "20px", backgroundColor: "#54B4D3" }} >
                                                <p className="card-text txt"  >Category: {property.category}</p>
                                                <p className="card-text txt">Type: {property.type}</p>

                                                <p className="card-text txt">Furnished: {property.furnished}</p>
                                                <p className="card-text txt">Number of Rooms: {property.numberOfRooms}</p>
                                                <p className="card-text txt">Price: ₹{property.Price}</p>
                                                <p className="card-text txt">City: {property.city}</p>
                                                <p className="card-text txt">Number Of Balconies: {property.numberOfBalconies}</p>
                                                <p className="card-text txt">Number Of Bathrooms: {property.numberOfBathrooms}</p>
                                                <p className="card-text txt">Number Of Rooms: {property.numberOfRooms}</p>
                                                <p className='txt'>Independent: {property.independent ? 'Yes' : 'No'}</p>
                                                <p className='txt'>Parking: {property.parking ? 'Yes' : 'No'}</p>
                                                <p className='txt'>Add to Favorites: {property.addToFavorites ? 'Yes' : 'No'}</p>
                                                <p className='txt'>Food Charges Include: {property.FoodChargesInclude ? 'Yes' : 'No'}</p>
                                                <p className='txt'>Electricity Charge: {property.ElectricityCharge ? 'Yes' : 'No'}</p>



                                            </div>

                                            <div className="col-md-6 mb-4 p-4 shadow" style={{ borderRadius: "20px", backgroundColor: "#54B4D3" }}>
                                                <h6>Facilities:</h6>
                                                <ul className="list-unstyled">
                                                    {property?.facilities?.map((facility, index) => (
                                                        <li key={index}> <p className='txt'>{facility}</p> </li>
                                                    ))}
                                                </ul>

                                                <h6>Security Deposits:</h6>
                                                <ul className="list-unstyled">
                                                    {property?.securityDeposit?.map((security, index) => (
                                                        <li key={index}>
                                                            <p className='txt'>Price: {security.price}</p>
                                                            <p className='txt'>Duration: {security.duration}</p>

                                                        </li>
                                                    ))}

                                                </ul>


                                                <h6>Rules:</h6>
                                                <ul className="list-unstyled">
                                                    {property.rules?.map((rule, index) => (
                                                        <li key={index}> <p className='txt'>{rule}</p> </li>
                                                    ))}
                                                </ul>

                                                <h6>Nearby Landmarks:</h6>
                                                <ul className="list-unstyled">
                                                    {property?.nearbyLandmarks?.map((landmark, index) => (
                                                        <li key={index}> <p className='txt'>{landmark}</p> </li>
                                                    ))}
                                                </ul>

                                                <h6>Food Availability:</h6>
                                                <ul className="list-unstyled">
                                                    {property?.FoodAvailable?.map((food, index) => (
                                                        <li key={index}> <p className='txt'>{food}</p> </li>
                                                    ))}
                                                </ul>


                                                <h6>Extra Charge:</h6>
                                                <ul className="list-unstyled">
                                                    {property?.extraCharges?.map((extra, index) => (
                                                        <li key={index}> <p className='txt'>{extra}</p> </li>
                                                    ))}
                                                </ul>

                                                <h6>Area:</h6>
                                                <p className="card-text txt">Name: {property.area[0]?.name}</p>
                                                <p className="card-text txt">Size: {property.area[0]?.size}</p>
                                            </div>
                                        </div>
                                        <div className='row '>

                                            <div className='col-md-12 mb-4 p-4 shadow ' style={{ borderRadius: "20px", backgroundColor: "#54B4D3" }}>
                                                <h5 className="card-title text-center text-uppercase">Owner Information </h5>
                                                <p className="card-text txt"> Owner  Name :{property?.ownerName}</p>
                                                <p className="card-text txt" > Owner  Email :<span style={{ fontSize: "15px" }}>{property?.ownerEmail}</span>  </p>
                                                <p className="card-text txt"> Owner  Number :{property?.ownerNumber ? property.ownerNumber : "null"}</p>


                                            </div>
                                            <div className='col-md-12 mb-4 p-4 shadow ' style={{ borderRadius: "20px", backgroundColor: "#54B4D3" }}>
                                                <h5 className="card-title text-center text-uppercase">Description </h5>

                                                <p className="card-text txt " style={{ color: "white" }}>{property.description}</p>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </Modal.Body>
                        ))}



                        <Modal.Footer>
                            <Button variant="secondary" onClick={handleCloseModal}>
                                Close
                            </Button>
                        </Modal.Footer>
                    </Modal>
                    {/* modal end for view */}

                    {/* Delete Confirmation Modal */}
                    <Modal show={showDeleteModal} onHide={handleCloseDeleteModal}>
                        <Modal.Header closeButton>
                            <Modal.Title>Delete Confirmation</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            Are you sure you want to delete this customer?
                        </Modal.Body>
                        <Modal.Footer>
                            <div className="container">
                                <div className="row">
                                    <div className="col">
                                        <Button variant="secondary" onClick={handleCloseDeleteModal}>
                                            Cancel
                                        </Button>
                                    </div>
                                    <div className="col">
                                        <Button variant="danger" onClick={handleDeleteConfirm} style={{marginLeft:"60%"}}>
                                            Delete
                                        </Button>
                                    </div>
                                </div>
                            </div>
                        </Modal.Footer>
                    </Modal>


                    {/* Edit  Customer Modal*/}
                    <Modal show={showEditModal} onHide={handleCloseModal} size="lg" dialogClassName="modal-lg">
                        <Modal.Header closeButton>
                            <Modal.Title>Property Details</Modal.Title>
                        </Modal.Header>
                        {Array.isArray(editPgdata) && editPgdata.map((property, index) => (
                            <Modal.Body key={index} style={{ borderRadius: "20px", width: "100%" }}>
                                <div className="card" style={{ borderRadius: "20px", backgroundColor: "#54B4D3" }}>
                                    <h1 className="card-title text-center text-uppercase" style={{ color: "white" }}>{property.name}</h1>
                                    <Carousel activeIndex={activeIndex} onSelect={handleSelect} >
                                        {property.images.map((image, index) => (
                                            <Carousel.Item key={index} style={{ borderRadius: "20px" }}>
                                                <img
                                                    src={`http://localhost:4500${image}`}
                                                    alt={`Image ${index}`}
                                                    className="d-block w-100 "
                                                    style={{ width: '100%', height: '300px', objectFit: 'cover' }}
                                                />
                                            </Carousel.Item>
                                        ))}
                                    </Carousel>
                                    <div className="card-body">
                                        <div className="row">
                                            <div className="col-md-6 mb-4 p-4 gap-2 shadow " style={{ borderRadius: "20px", backgroundColor: "#54B4D3" }} >
                                                {/* Category Field */}
                                                <div className="field">
                                                    <label>Category:</label>
                                                    {editedField === 'category' ? (
                                                        <FormControl
                                                            type="text"
                                                            value={editedData.category || property.category}
                                                            onChange={(e) => handleEdit('category', e.target.value)}
                                                        />
                                                    ) : (
                                                        <>
                                                            <span className="card-text txt">{property.category}</span>
                                                            <span className="edit-icon btn" onClick={() => handleEdit('category', property.category)}>✎</span>
                                                        </>
                                                    )}
                                                </div>
                                                {/* Type Field */}
                                                <div className="field">
                                                    <label>Type:</label>
                                                    {editedField === 'type' ? (
                                                        <FormControl
                                                            type="text"
                                                            value={editedData.type || property.type}
                                                            onChange={(e) => handleEdit('type', e.target.value)}
                                                        />
                                                    ) : (
                                                        <>
                                                            <span className="card-text txt">{property.type}</span>
                                                            <span className="edit-icon btn" onClick={() => handleEdit('type', property.type)}>✎</span>
                                                        </>
                                                    )}
                                                </div>
                                                {/* Furnished Field */}
                                                <div className="field">
                                                    <label>Furnished:</label>
                                                    {editedField === 'furnished' ? (
                                                        <FormControl
                                                            type="text"
                                                            value={editedData.furnished || property.furnished}
                                                            onChange={(e) => handleEdit('furnished', e.target.value)}
                                                        />
                                                    ) : (
                                                        <>
                                                            <span className="card-text txt">{property.furnished}</span>
                                                            <span className="edit-icon btn" onClick={() => handleEdit('furnished', property.furnished)}>✎</span>
                                                        </>
                                                    )}
                                                </div>
                                                {/* Number of Rooms Field */}
                                                <div className="field">
                                                    <label>Number of Rooms:</label>
                                                    {editedField === 'numberOfRooms' ? (
                                                        <FormControl
                                                            type="text"
                                                            value={editedData.numberOfRooms || property.numberOfRooms}
                                                            onChange={(e) => handleEdit('numberOfRooms', e.target.value)}
                                                        />
                                                    ) : (
                                                        <>
                                                            <span className="card-text txt">{property.numberOfRooms}</span>
                                                            <span className="edit-icon btn" onClick={() => handleEdit('numberOfRooms', property.numberOfRooms)}>✎</span>
                                                        </>
                                                    )}
                                                </div>
                                                {/* Price Field */}
                                                <div className="field">
                                                    <label>Price:</label>
                                                    {editedField === 'Price' ? (
                                                        <FormControl
                                                            type="text"
                                                            value={editedData.Price || property.Price}
                                                            onChange={(e) => handleEdit('Price', e.target.value)}
                                                        />
                                                    ) : (
                                                        <>
                                                            <span className="card-text txt">₹{property.Price}</span>
                                                            <span className="edit-icon btn" onClick={() => handleEdit('Price', property.Price)}>✎</span>
                                                        </>
                                                    )}
                                                </div>
                                                {/* City Field */}
                                                <div className="field">
                                                    <label>City:</label>
                                                    {editedField === 'city' ? (
                                                        <FormControl
                                                            type="text"
                                                            value={editedData.city || property.city}
                                                            onChange={(e) => handleEdit('city', e.target.value)}
                                                        />
                                                    ) : (
                                                        <>
                                                            <span className="card-text txt">{property.city}</span>
                                                            <span className="edit-icon btn" onClick={() => handleEdit('city', property.city)}>✎</span>
                                                        </>
                                                    )}
                                                </div>
                                                {/* Number Of Balconies Field */}
                                                <div className="field">
                                                    <label>Number Of Balconies:</label>
                                                    {editedField === 'numberOfBalconies' ? (
                                                        <FormControl
                                                            type="text"
                                                            value={editedData.numberOfBalconies || property.numberOfBalconies}
                                                            onChange={(e) => handleEdit('numberOfBalconies', e.target.value)}
                                                        />
                                                    ) : (
                                                        <>
                                                            <span className="card-text txt">{property.numberOfBalconies}</span>
                                                            <span className="edit-icon btn" onClick={() => handleEdit('numberOfBalconies', property.numberOfBalconies)}>✎</span>
                                                        </>
                                                    )}
                                                </div>
                                                {/* Number Of Bathrooms Field */}
                                                <div className="field">
                                                    <label>Number Of Bathrooms:</label>
                                                    {editedField === 'numberOfBathrooms' ? (
                                                        <FormControl
                                                            type="text"
                                                            value={editedData.numberOfBathrooms || property.numberOfBathrooms}
                                                            onChange={(e) => handleEdit('numberOfBathrooms', e.target.value)}
                                                        />
                                                    ) : (
                                                        <>
                                                            <span className="card-text txt">{property.numberOfBathrooms}</span>
                                                            <span className="edit-icon btn" onClick={() => handleEdit('numberOfBathrooms', property.numberOfBathrooms)}>✎</span>
                                                        </>
                                                    )}
                                                </div>
                                                {/* Independent Field */}
                                                <div className="field">
                                                    <label>Independent:</label>
                                                    {editedField === 'independent' ? (
                                                        <FormControl
                                                            type="text"
                                                            value={editedData.independent || property.independent}
                                                            onChange={(e) => handleEdit('independent', e.target.value)}
                                                        />
                                                    ) : (
                                                        <>
                                                            <span className="card-text txt">{property.independent ? 'Yes' : 'No'}</span>
                                                            <span className="edit-icon btn" onClick={() => handleEdit('independent', property.independent)}>✎</span>
                                                        </>
                                                    )}
                                                </div>
                                                {/* Parking Field */}
                                                <div className="field">
                                                    <label>Parking:</label>
                                                    {editedField === 'parking' ? (
                                                        <FormControl
                                                            type="text"
                                                            value={editedData.parking || property.parking}
                                                            onChange={(e) => handleEdit('parking', e.target.value)}
                                                        />
                                                    ) : (
                                                        <>
                                                            <span className="card-text txt">{property.parking ? 'Yes' : 'No'}</span>
                                                            <span className="edit-icon btn" onClick={() => handleEdit('parking', property.parking)}>✎</span>
                                                        </>
                                                    )}
                                                </div>
                                                {/* Add to Favorites Field */}
                                                <div className="field">
                                                    <label>Add to Favorites:</label>
                                                    {editedField === 'addToFavorites' ? (
                                                        <FormControl
                                                            type="text"
                                                            value={editedData.addToFavorites || property.addToFavorites}
                                                            onChange={(e) => handleEdit('addToFavorites', e.target.value)}
                                                        />
                                                    ) : (
                                                        <>
                                                            <span className="card-text txt">{property.addToFavorites ? 'Yes' : 'No'}</span>
                                                            <span className="edit-icon btn" onClick={() => handleEdit('addToFavorites', property.addToFavorites)}>✎</span>
                                                        </>
                                                    )}
                                                </div>
                                                {/* Food Charges Include Field */}
                                                <div className="field">
                                                    <label>Food Charges Include:</label>
                                                    {editedField === 'FoodChargesInclude' ? (
                                                        <FormControl
                                                            type="text"
                                                            value={editedData.FoodChargesInclude || property.FoodChargesInclude}
                                                            onChange={(e) => handleEdit('FoodChargesInclude', e.target.value)}
                                                        />
                                                    ) : (
                                                        <>
                                                            <span className="card-text txt">{property.FoodChargesInclude ? 'Yes' : 'No'}</span>
                                                            <span className="edit-icon btn" onClick={() => handleEdit('FoodChargesInclude', property.FoodChargesInclude)}>✎</span>
                                                        </>
                                                    )}
                                                </div>
                                                {/* Electricity Charge Field */}
                                                <div className="field">
                                                    <label>Electricity Charge:</label>
                                                    {editedField === 'ElectricityCharge' ? (
                                                        <FormControl
                                                            type="text"
                                                            value={editedData.ElectricityCharge || property.ElectricityCharge}
                                                            onChange={(e) => handleEdit('ElectricityCharge', e.target.value)}
                                                        />
                                                    ) : (
                                                        <>
                                                            <span className="card-text txt">{property.ElectricityCharge ? 'Yes' : 'No'}</span>
                                                            <span className="edit-icon btn" onClick={() => handleEdit('ElectricityCharge', property.ElectricityCharge)}>✎</span>
                                                        </>
                                                    )}
                                                </div>

                                            </div>


                                            {/* another div */}
                                            <div className="col-md-6 mb-4 p-4 gap-2 shadow " style={{ borderRadius: "20px", backgroundColor: "#54B4D3" }} >
                                                {/* Facilities Field */}
                                                <div className="field">
                                                    <label>Facilities:</label>
                                                    <ul>
                                                        {property?.facilities?.map((facility, index) => (
                                                            <li key={index}>
                                                                {editedField === `facilities_${index}` ? (
                                                                    <FormControl
                                                                        type="text"
                                                                        value={editedData[`facilities_${index}`] || facility}
                                                                        onChange={(e) => handleEdit(`facilities_${index}`, e.target.value)}
                                                                    />
                                                                ) : (
                                                                    <>
                                                                        <span className="card-text txt">{facility}</span>
                                                                        <span className="edit-icon" onClick={() => handleEdit(`facilities_${index}`, facility)}>✎</span>
                                                                    </>
                                                                )}
                                                            </li>
                                                        ))}
                                                    </ul>
                                                </div>
                                                {/* Security Deposits Field */}
                                                <div className="field">
                                                    <label>Security Deposits:</label>
                                                    <ul>
                                                        {property?.securityDeposit?.map((security, index) => (
                                                            <li key={index}>
                                                                {editedField === `securityDeposit_price_${index}` ? (
                                                                    <FormControl
                                                                        type="text"
                                                                        value={editedData[`securityDeposit_price_${index}`] || security.price}
                                                                        onChange={(e) => handleEdit(`securityDeposit_price_${index}`, e.target.value)}
                                                                    />
                                                                ) : (
                                                                    <>
                                                                        <p className="card-text txt">Price: {security.price}</p>
                                                                        <p className="card-text txt">Duration: {security.duration}</p>
                                                                        <span className="edit-icon" onClick={() => handleEdit(`securityDeposit_price_${index}`, security.price)}>✎</span>
                                                                    </>
                                                                )}
                                                            </li>
                                                        ))}
                                                    </ul>
                                                </div>
                                                {/* Rules Field */}
                                                <div className="field">
                                                    <label>Rules:</label>
                                                    <ul>
                                                        {property.rules?.map((rule, index) => (
                                                            <li key={index}>
                                                                {editedField === `rules_${index}` ? (
                                                                    <FormControl
                                                                        type="text"
                                                                        value={editedData[`rules_${index}`] || rule}
                                                                        onChange={(e) => handleEdit(`rules_${index}`, e.target.value)}
                                                                    />
                                                                ) : (
                                                                    <>
                                                                        <span className="card-text txt">{rule}</span>
                                                                        <span className="edit-icon" onClick={() => handleEdit(`rules_${index}`, rule)}>✎</span>
                                                                    </>
                                                                )}
                                                            </li>
                                                        ))}
                                                    </ul>
                                                </div>
                                                {/* Nearby Landmarks Field */}
                                                <div className="field">
                                                    <label>Nearby Landmarks:</label>
                                                    <ul>
                                                        {property?.nearbyLandmarks?.map((landmark, index) => (
                                                            <li key={index}>
                                                                {editedField === `nearbyLandmarks_${index}` ? (
                                                                    <FormControl
                                                                        type="text"
                                                                        value={editedData[`nearbyLandmarks_${index}`] || landmark}
                                                                        onChange={(e) => handleEdit(`nearbyLandmarks_${index}`, e.target.value)}
                                                                    />
                                                                ) : (
                                                                    <>
                                                                        <span className="card-text txt">{landmark}</span>
                                                                        <span className="edit-icon" onClick={() => handleEdit(`nearbyLandmarks_${index}`, landmark)}>✎</span>
                                                                    </>
                                                                )}
                                                            </li>
                                                        ))}
                                                    </ul>
                                                </div>
                                                {/* Food Availability Field */}
                                                <div className="field">
                                                    <label>Food Availability:</label>
                                                    <ul>
                                                        {property?.FoodAvailable?.map((food, index) => (
                                                            <li key={index}>
                                                                {editedField === `FoodAvailable_${index}` ? (
                                                                    <FormControl
                                                                        type="text"
                                                                        value={editedData[`FoodAvailable_${index}`] || food}
                                                                        onChange={(e) => handleEdit(`FoodAvailable_${index}`, e.target.value)}
                                                                    />
                                                                ) : (
                                                                    <>
                                                                        <span className="card-text txt">{food}</span>
                                                                        <span className="edit-icon" onClick={() => handleEdit(`FoodAvailable_${index}`, food)}>✎</span>
                                                                    </>
                                                                )}
                                                            </li>
                                                        ))}
                                                    </ul>
                                                </div>
                                                {/* Extra Charge Field */}
                                                <div className="field">
                                                    <label>Extra Charge:</label>
                                                    <ul>
                                                        {property?.extraCharges?.map((extra, index) => (
                                                            <li key={index}>
                                                                {editedField === `extraCharges_${index}` ? (
                                                                    <FormControl
                                                                        type="text"
                                                                        value={editedData[`extraCharges_${index}`] || extra}
                                                                        onChange={(e) => handleEdit(`extraCharges_${index}`, e.target.value)}
                                                                    />
                                                                ) : (
                                                                    <>
                                                                        <span className="card-text txt">{extra}</span>
                                                                        <span className="edit-icon" onClick={() => handleEdit(`extraCharges_${index}`, extra)}>✎</span>
                                                                    </>
                                                                )}
                                                            </li>
                                                        ))}
                                                    </ul>
                                                </div>
                                                {/* Area Field */}
                                                <div className="field">
                                                    <label>Area:</label>
                                                    {property?.area?.map((area, index) => (
                                                        <div key={index}>
                                                            {/* Area Name */}
                                                            <div className="field">
                                                                <label>Name:</label>
                                                                {editedField === `area_name_${index}` ? (
                                                                    <FormControl
                                                                        type="text"
                                                                        value={editedData[`area_name_${index}`] || area.name}
                                                                        onChange={(e) => handleEdit(`area_name_${index}`, e.target.value)}
                                                                    />
                                                                ) : (
                                                                    <>
                                                                        <span className="card-text txt">{area.name}</span>
                                                                        <span className="edit-icon" onClick={() => handleEdit(`area_name_${index}`, area.name)}>✎</span>
                                                                    </>
                                                                )}
                                                            </div>
                                                            {/* Area Size */}
                                                            <div className="field">
                                                                <label>Size:</label>
                                                                {editedField === `area_size_${index}` ? (
                                                                    <FormControl
                                                                        type="text"
                                                                        value={editedData[`area_size_${index}`] || area.size}
                                                                        onChange={(e) => handleEdit(`area_size_${index}`, e.target.value)}
                                                                    />
                                                                ) : (
                                                                    <>
                                                                        <p className="card-text txt">{area.size}</p>
                                                                        <span className="edit-icon" onClick={() => handleEdit(`area_size_${index}`, area.size)}>✎</span>
                                                                    </>
                                                                )}
                                                            </div>
                                                        </div>
                                                    ))}
                                                </div>

                                            </div>
                                        </div>

                                        <div className='row'>
                                            {/* Owner Information */}
                                            <div className='col-md-12 mb-4 p-4 shadow' style={{ borderRadius: "20px", backgroundColor: "#54B4D3" }}>
                                                <h5 className="card-title text-center text-uppercase">Owner Information</h5>
                                                {/* Owner Name */}
                                                <div className="field">
                                                    <label>Owner Name:</label>
                                                    {editedField === 'ownerName' ? (
                                                        <FormControl
                                                            type="text"
                                                            value={editedData.ownerName || property.ownerName}
                                                            onChange={(e) => handleEdit('ownerName', e.target.value)}
                                                        />
                                                    ) : (
                                                        <>
                                                            <p className="card-text txt">{property?.ownerName}</p>
                                                            <span className="edit-icon btn" onClick={() => handleEdit('ownerName', property.ownerName)}>✎</span>
                                                        </>

                                                    )}
                                                </div>
                                                {/* Owner Email */}
                                                <div className="field">
                                                    <label>Owner Email:</label>
                                                    {editedField === 'ownerEmail' ? (
                                                        <FormControl
                                                            type="text"
                                                            value={editedData.ownerEmail || property.ownerEmail}
                                                            onChange={(e) => handleEdit('ownerEmail', e.target.value)}
                                                        />
                                                    ) : (

                                                        <>
                                                            <p className="card-text txt">{property?.ownerEmail}</p>
                                                            <span className="edit-icon btn" onClick={() => handleEdit('ownerEmail', property?.ownerEmail)}>✎</span>
                                                        </>
                                                    )}
                                                </div>
                                                {/* Owner Number */}
                                                <div className="field">
                                                    <label>Owner Number:</label>
                                                    {editedField === 'ownerNumber' ? (
                                                        <FormControl
                                                            type="text"
                                                            value={editedData.ownerNumber || property.ownerNumber}
                                                            onChange={(e) => handleEdit('ownerNumber', e.target.value)}
                                                        />
                                                    ) : (
                                                        <>
                                                            <p className="card-text txt">{property?.ownerNumber ? property.ownerNumber : "null"}</p>
                                                            <span className="edit-icon btn" onClick={() => handleEdit('ownerNumber', property?.ownerNumber)}>✎</span>
                                                        </>
                                                    )}
                                                </div>
                                            </div>
                                            {/* Description */}
                                            <div className='col-md-12 mb-4 p-4 shadow' style={{ borderRadius: "20px", backgroundColor: "#54B4D3" }}>
                                                <h5 className="card-title text-center text-uppercase">Description</h5>
                                                <div className="field">
                                                    {editedField === 'description' ? (
                                                        <FormControl
                                                            as="textarea"
                                                            rows={3}
                                                            value={editedData.description || property.description}
                                                            onChange={(e) => handleEdit('description', e.target.value)}
                                                        />
                                                    ) : (
                                                        <>
                                                            <span className="edit-icon btn" onClick={() => handleEdit('description', property?.description)}>✎</span>
                                                            <p className="card-text txt" style={{ color: "white" }}>{property.description}</p>
                                                        </>
                                                    )}
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </Modal.Body>
                        ))}
                        <Modal.Footer>
                            <Button variant="secondary" onClick={handleCloseModal}>Close</Button>
                            <Button variant="primary" onClick={handleSaveChanges}>Save Changes</Button>
                        </Modal.Footer>
                    </Modal>



                    <div className="clearfix">
                        <div className="hint-text">Showing <b>5</b> out of <b>{datas?.length}</b> entries</div>
                        <ul className="pagination">
                            <li className="page-item disabled"><a href="#"><i className="fa fa-angle-double-left"></i></a></li>
                            <li className="page-item"><a href="#" className="page-link">1</a></li>
                            <li className="page-item"><a href="#" className="page-link">2</a></li>
                            <li className="page-item active"><a href="#" className="page-link">3</a></li>
                            <li className="page-item"><a href="#" className="page-link">4</a></li>
                            <li className="page-item"><a href="#" className="page-link">5</a></li>
                            <li className="page-item"><a href="#" className="page-link"><i className="fa fa-angle-double-right"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div >
    );
};

export default MyListing;
