import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useFormik } from 'formik';
import { useNavigate } from "react-router-dom";

import { Modal, Button, Form, ProgressBar, Alert } from 'react-bootstrap';
import { toast, ToastContainer } from 'react-toastify';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import './Profile.css'
import { Container, Row, Col, Tab, Nav } from 'react-bootstrap';
import validationSchema from '../FormikFunction';


const Profile = () => {
    const [show, setShow] = useState(false);
    const [step, setStep] = useState(1);
    const [ownerDetails, setOwnerDetails] = useState([]);
    const navigate = useNavigate()

    useEffect(() => {
        const fetchData = async () => {
            try {
                // const response = await axios.get(`http://localhost:4500/getProfile/${ownerId}`);
                const response = await axios.get(`http://localhost:4500/getProfile/656f1300cc8ea22923e166e0`);

                setOwnerDetails(response?.data?.data);
                console.log("response", response?.data?.data)
            } catch (error) {
                console.error('Error fetching owner details:', error);
            }
        };

        fetchData();
    }, []);

    const initialValues = {

        f_name: '',
        l_name: '',
        email: '',
        phone: '',
        date_of_birth: null,
        city: '',
        state: '',
        zip_code: '',
        description: '',
        company_name: '',
        currency_name: '',
        employment_type: '',
        image: null,
        ownerId: "657be995fa95b402bb373ed4"
    };

    const [displayData, setDisplayData] = useState(null);
    const indianStates = [
        "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh", "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand",
        "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya",
        "Mizoram", "Nagaland", "Odisha", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal",
    ];
    const handleClose = () => {
        setShow(false);
        setDisplayData(null);
    };

    const handleShow = () => setShow(true);

    const handleNextStep = () => setStep((prevStep) => prevStep + 1);

    const handlePrevStep = () => setStep((prevStep) => prevStep - 1);

    const formik = useFormik({
        initialValues,
        validationSchema,
        onSubmit: async () => {
            console.log("submitted");
            // console.log({ values });

            if (formik.isValid) {
                console.log("Form is valid");
                try {
                    let formData = new FormData();

                    // Append new fields to FormData

                    formData.append("ownerId", values.ownerId);
                    formData.append("f_name", values.f_name);
                    formData.append("l_name", values.l_name);
                    formData.append("email", values.email);
                    formData.append("phone", values.phone);
                    formData.append("date_of_birth", values.date_of_birth);
                    formData.append("city", values.city);
                    formData.append("state", values.state);
                    formData.append("zip_code", values.zip_code);
                    formData.append("description", values.description);
                    formData.append("company_name", values.company_name);
                    formData.append("currency_name", values.currency_name);
                    formData.append("employment_type", values.employment_type);

                    if (values.image) {
                        formData.append("image", values.image);
                    }

                    // Replace '/api/send-otp' with your actual API endpoint
                    await axios.post("http://localhost:4500/createProfile", formData, {
                        headers: {
                            "Content-Type": "multipart/form-data",
                        },
                    }).then((res) => {
                        console.log("pg created:", res.data);
                        // localStorage.setItem("token", res.data.token);
                        toast.success(res.data.message, {
                            position: "top-right",
                            autoClose: 5000,
                            hideProgressBar: false,
                            closeOnClick: true,
                            pauseOnHover: true,
                            draggable: true,
                            progress: undefined,
                            theme: "light",
                        });
                        setTimeout(() => {
                            // navigate("/ownerDashboard");
                        }, 2000);
                    });
                    // Handle successful form submission
                } catch (error) {
                    console.log({ error })
                    console.error("Error Registering Form:", error);
                    toast.failure("Error Registering Form", {
                        position: "top-right",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                        theme: "light",
                    });
                }
            } else {
                console.log("Form is not valid");
                console.log("Errors:", formik.errors);
                console.log("Touched:", formik.touched);
            }
        },
    });

    const {
        handleSubmit,
        handleChange,
        handleBlur,
        values,
        errors,
        touched,
    } = formik;


    const wordCount = values?.description?.length;
    const formatDate = (dateString) => {
        const date = new Date(dateString);
        return date.toISOString().split('T')[0]; // Extract YYYY-MM-DD part
    };
    return (
        <>
            <div>
                {ownerDetails.map((owner) => (
                    <section className="section about-section gray-bg" id="about" >
                        <div className='profile' style={{ position: "relative", paddingBottom: "10px", maxWidth: "90%", marginLeft: "5%", display: "flex", alignItems: "center", justifyContent: "center" }}>
                            <h3 className="dark-color">
                                My Profile
                            </h3>
                            <Button variant="danger" onClick={handleShow} className='ml-auto mb-2'>
                                {step === 1 ? '+ Edit Profile' : '+ Edit Profile'}
                            </Button>
                        </div>
                        <Container>
                            <Row className="align-items-center flex-row-reverse">
                                <Col lg={6}>
                                    <div className="about-text go-to">
                                        <h6 className="theme-color lead">Here Is Your  Information</h6>
                                        {/* description */}
                                        <p>
                                            {owner?.description || 'Null'}
                                        </p>
                                        <Row className="about-list">
                                            <Col md={6}>
                                                <div className="media">
                                                    <label>Birthday</label>
                                                    <p> {formatDate(owner?.date_of_birth) || 'Null'}</p>
                                                </div>
                                                <div className="media">
                                                    <label>State</label>
                                                    <p>{owner?.state || 'Null'}</p>
                                                </div>
                                                <div className="media">
                                                    <label>City</label>
                                                    <p>{owner?.city || 'Null'}</p>
                                                </div>
                                                <div className="media">
                                                    <label> Pin Code</label>
                                                    <p>{owner?.zip_code || 'Null'}</p>
                                                </div>
                                            </Col>
                                            <Col md={6}>
                                                <div className="media">
                                                    <label>E-mail</label>
                                                    <p>{owner?.email || 'Null'}</p>
                                                </div>
                                                <div className="media">
                                                    <label>Phone</label>
                                                    <p>{owner?.phone || 'Null'}</p>
                                                </div>
                                                <div className="media">
                                                    <label>Company Name</label>
                                                    <p>{owner?.company_name || 'Null'}</p>
                                                </div>
                                                <div className="media">
                                                    <label>Currency Name</label>
                                                    <p>{owner?.currency_name || 'Null'}</p>
                                                </div>
                                            </Col>
                                        </Row>

                                    </div>
                                </Col>
                                <Col lg={6}>
                                    <div className="about-avatar">
                                        <img
                                            src={`http://localhost:4500/uploads/${owner?.image}`}
                                            title=""
                                            alt=""

                                            style={{ width: "200px", marginLeft: "20%", height: "200px", borderRadius: "50%", border: "2px solid #fff" }}
                                        />
                                    </div>
                                    <div className="media " style={{ marginTop: "10px", marginLeft: "20%" }}>
                                        <h2 className="dark-color">{owner?.ownerName || 'Null'}</h2>
                                    </div>
                                </Col>
                            </Row>
                            <div className="counter">
                                <Row>
                                    <Col xs={6} lg={3}>
                                        <div className="count-data text-center">
                                            <h6 className="count h2" data-to="500" data-speed="500">
                                                500
                                            </h6>
                                            <p className="m-0px font-w-600">Happy Clients</p>
                                        </div>
                                    </Col>
                                    <Col xs={6} lg={3}>
                                        <div className="count-data text-center">
                                            <h6 className="count h2" data-to="150" data-speed="150">
                                                150
                                            </h6>
                                            <p className="m-0px font-w-600">Project Completed</p>
                                        </div>
                                    </Col>
                                    <Col xs={6} lg={3}>
                                        <div className="count-data text-center">
                                            <h6 className="count h2" data-to="850" data-speed="850">
                                                850
                                            </h6>
                                            <p className="m-0px font-w-600">Photo Capture</p>
                                        </div>
                                    </Col>
                                    <Col xs={6} lg={3}>
                                        <div className="count-data text-center">
                                            <h6 className="count h2" data-to="190" data-speed="190">
                                                190
                                            </h6>
                                            <p className="m-0px font-w-600">Telephonic Talk</p>
                                        </div>
                                    </Col>
                                </Row>
                            </div>

                        </Container>
                    </section>
                ))}



                {displayData && (
                    <Alert variant="success" className="mt-3">
                        <strong>Entered Information:</strong> {JSON.stringify(displayData)}
                    </Alert>
                )}

                <Modal show={show} onHide={handleClose} centered dialogClassName="custom-modal" >
                    <Modal.Header closeButton>
                        <Modal.Title>Edit Profile</Modal.Title>
                    </Modal.Header>

                    <Modal.Body>
                        <ProgressBar now={(step / 3) * 100} label={`${step}/3`} style={{ Color: "green" }} />
                        <br />

                        {step === 1 && (
                            <Form onSubmit={handleSubmit}>
                                <div className='container'>
                                    <fieldset>
                                        <legend> Personal Details! </legend>
                                        <div className="form-group row">
                                            <label className="control-label"> Name</label>
                                            <div className="col-md-12">
                                                <div className="input-group">
                                                    <span className="input-group-addon">
                                                        <i className="glyphicon glyphicon-user"></i>
                                                    </span>

                                                    <input
                                                        name="f_name"
                                                        placeholder="First Name"
                                                        className={`form-control mr-3 ${touched.f_name && errors.f_name ? 'is-invalid' : ''}`}
                                                        type="text"
                                                        value={values.f_name}
                                                        onChange={handleChange}
                                                        onBlur={handleBlur}
                                                    />
                                                    {/* Display error message if touched and there's an error */}
                                                    {touched.f_name && errors.f_name && <div className="invalid-feedback">{errors.f_name}</div>}
                                                    <input
                                                        name="l_name"
                                                        placeholder="Last Name"
                                                        className={`form-control ${touched.l_name && errors.l_name ? 'is-invalid' : ''}`}
                                                        type="text"
                                                        value={values.l_name}
                                                        onChange={handleChange}
                                                        onBlur={handleBlur}
                                                    />
                                                    {/* Display error message if touched and there's an error */}
                                                    {touched.l_name && errors.l_name && <div className="invalid-feedback">{errors.l_name}</div>}
                                                </div>
                                            </div>
                                        </div>

                                        {/* Email and Phone in one line */}
                                        <div className="form-group row">
                                            <div className="col-md-6">
                                                <label className="control-label">Email</label>
                                                <div className="input-group">
                                                    <span className="input-group-addon">
                                                        <i className="glyphicon glyphicon-envelope"></i>
                                                    </span>
                                                    <input
                                                        name="email"
                                                        placeholder="Email Address"
                                                        className={`form-control ${touched.email && errors.email ? 'is-invalid' : ''}`}
                                                        type="text"
                                                        value={values.email}
                                                        onChange={handleChange}
                                                        onBlur={handleBlur}
                                                    />
                                                    {touched.email && errors.email && <div className="invalid-feedback">{errors.email}</div>}
                                                </div>
                                            </div>
                                            <div className="col-md-6">
                                                <label className="control-label">Phone</label>
                                                <div className="input-group">
                                                    <span className="input-group-addon">
                                                        <i className="glyphicon glyphicon-earphone"></i>
                                                    </span>
                                                    <input
                                                        name="phone"
                                                        placeholder="(845)555-1212"
                                                        className={`form-control ${touched.phone && errors.phone ? 'is-invalid' : ''}`}
                                                        type="text"
                                                        value={values.phone}
                                                        onChange={handleChange}
                                                        onBlur={handleBlur}
                                                    />
                                                    {touched.phone && errors.phone && <div className="invalid-feedback">{errors.phone}</div>}
                                                </div>
                                            </div>
                                        </div>
                                        {/* Date of Birth and City in one line */}
                                        <div className="form-group row">
                                            <div className="col-md-6">
                                                <label className="control-label">DOB</label>
                                                <div className="input-group">
                                                    <span className="input-group-addon">
                                                        <i className="glyphicon glyphicon-home"></i>
                                                    </span>
                                                    <DatePicker
                                                        name="date_of_birth"
                                                        className={`form-control ${touched.date_of_birth && errors.date_of_birth ? 'is-invalid' : ''}`}
                                                        selected={values.date_of_birth}
                                                        onChange={(date) => formik.setFieldValue('date_of_birth', date)}
                                                        placeholderText="Select Date of Birth"
                                                        dateFormat="MM/dd/yyyy"
                                                    />
                                                    {touched.date_of_birth && errors.date_of_birth && (
                                                        <div className="invalid-feedback">{errors.date_of_birth}</div>
                                                    )}
                                                </div>
                                            </div>

                                            <div className="col-md-6">
                                                <label className="control-label">City</label>
                                                <div className="input-group">
                                                    <span className="input-group-addon">
                                                        <i className="glyphicon glyphicon-home"></i>
                                                    </span>
                                                    <input
                                                        name="city"
                                                        placeholder="City"
                                                        className={`form-control ${touched.city && errors.city ? 'is-invalid' : ''}`}
                                                        type="text"
                                                        value={values.city}
                                                        onChange={handleChange}
                                                        onBlur={handleBlur}
                                                    />
                                                    {touched.city && errors.city && <div className="invalid-feedback">{errors.city}</div>}
                                                </div>
                                            </div>
                                        </div>

                                        {/* State and zip_code Code in one line */}
                                        <div className="form-group row">
                                            <div className="col-md-6">
                                                <label className="control-label">State</label>
                                                <div className="input-group">
                                                    <span className="input-group-addon">
                                                        <i className="glyphicon glyphicon-list"></i>
                                                    </span>
                                                    <select
                                                        name="state"
                                                        className={`form-control selectpicker ${touched.state && errors.state ? 'is-invalid' : ''}`}
                                                        value={values.state}
                                                        onChange={handleChange}
                                                        onBlur={handleBlur}
                                                    >
                                                        <option value="">Please select your state</option>
                                                        {indianStates.map((state, index) => (
                                                            <option key={index} value={state}>
                                                                {state}
                                                            </option>
                                                        ))}
                                                    </select>
                                                    {touched.state && errors.state && <div className="invalid-feedback">{errors.state}</div>}
                                                </div>
                                            </div>
                                            <div className="col-md-6">
                                                <label className="control-label">zip_code Code</label>
                                                <div className="input-group">
                                                    <span className="input-group-addon">
                                                        <i className="glyphicon glyphicon-home"></i>
                                                    </span>
                                                    <input
                                                        name="zip_code"
                                                        placeholder="zip Code"
                                                        className={`form-control ${touched.zip_code && errors.zip_code ? 'is-invalid' : ''}`}
                                                        type="text"
                                                        value={values.zip_code}
                                                        onChange={handleChange}
                                                        onBlur={handleBlur}
                                                    />
                                                    {touched.zip_code && errors.zip_code && <div className="invalid-feedback">{errors.zip_code}</div>}
                                                </div>
                                            </div>
                                        </div>

                                    </fieldset>
                                </div>


                                <Button variant="danger" onClick={handleNextStep} className='float-right' >
                                    Next
                                </Button>
                            </Form>
                        )}

                        {step === 2 && (
                            <Form onSubmit={handleSubmit}>
                                <div className='container'>
                                    <fieldset>
                                        <legend>Information</legend>
                                        <div className="form-group row">
                                            <label className="control-label">Company Name / Property Name</label>
                                            <div className="col-md-12">
                                                <div className="input-group">
                                                    <span className="input-group-addon">
                                                        <i className="glyphicon glyphicon-home"></i>
                                                    </span>
                                                    <input
                                                        name="company_name"
                                                        placeholder="Your Company Name / Property Name"
                                                        className={`form-control mr-3 ${touched.company_name && errors.company_name ? 'is-invalid' : ''}`}
                                                        type="text"
                                                        value={values.company_name}
                                                        onChange={handleChange}
                                                    />
                                                </div>
                                                {touched.company_name && errors.company_name && (
                                                    <div className="invalid-feedback">{errors.company_name}</div>
                                                )}
                                            </div>
                                        </div>

                                        <div className="form-group row">
                                            <label className="control-label">Select Currency</label>
                                            <div className="col-md-12">
                                                <div className="input-group">
                                                    <select
                                                        name="currency_name"
                                                        className={`form-control mr-3 ${touched.currency_name && errors.currency_name ? 'is-invalid' : ''}`}
                                                        value={values.currency_name}
                                                        onChange={handleChange}
                                                    >
                                                        <option value="">Select Currency</option>
                                                        <option value="INR">Indian Rupee (INR)</option>
                                                        <option value="USD">US Dollar (USD)</option>
                                                        <option value="CAD">Canadian Dollar (CAD)</option>
                                                        <option value="AUD">Australian Dollar (AUD)</option>
                                                        <option value="AED">UAE Dirham (AED)</option>
                                                        <option value="OMR">Omani Rial (OMR)</option>
                                                    </select>
                                                </div>
                                                {touched.currency_name && errors.currency_name && (
                                                    <div className="invalid-feedback">{errors.currency_name}</div>
                                                )}
                                            </div>
                                        </div>

                                        <div className="form-group row">
                                            <label className="control-label">Employment Type</label>
                                            <div className="col-md-12">
                                                <div className="input-group gap-3">
                                                    <label className="radio-inline">
                                                        <input
                                                            type="radio"
                                                            name="employment_type"
                                                            value="salaried"
                                                            checked={values.employment_type === 'salaried'}
                                                            onChange={handleChange}
                                                        />{' '}
                                                        Salaried
                                                    </label>
                                                    <label className="radio-inline">
                                                        <input
                                                            type="radio"
                                                            name="employment_type"
                                                            value="self_employed_business"
                                                            checked={values.employment_type === 'self_employed_business'}
                                                            onChange={handleChange}
                                                        />{' '}
                                                        Self Employed (Business)
                                                    </label>
                                                    <label className="radio-inline">
                                                        <input
                                                            type="radio"
                                                            name="employment_type"
                                                            value="self_employed_professional"
                                                            checked={values.employment_type === 'self_employed_professional'}
                                                            onChange={handleChange}
                                                        />{' '}
                                                        Self Employed (Professional)
                                                    </label>
                                                </div>
                                                {touched.employment_type && errors.employment_type && (
                                                    <div className="invalid-feedback">{errors.employment_type}</div>
                                                )}
                                            </div>
                                        </div>
                                    </fieldset>
                                </div>

                                <Button variant="secondary" onClick={handlePrevStep}>
                                    Previous
                                </Button>
                                <Button variant="danger" onClick={handleNextStep} className='float-right'>
                                    Next
                                </Button>
                            </Form>
                        )}

                        {step === 3 && (
                            <Form onSubmit={handleSubmit}>
                                <div className='container'>
                                    <fieldset>
                                        <legend>Information</legend>
                                        <div className="form-group row">
                                            <label className="control-label">Description</label>
                                            <div className="col-md-12">
                                                <div className="input-group">
                                                    <textarea
                                                        name="description"
                                                        placeholder="Description"
                                                        className={`form-control mr-3 ${touched.description && errors.description ? 'is-invalid' : ''}`}
                                                        rows="4"
                                                        value={values.description}
                                                        onChange={handleChange}
                                                    />
                                                    <div style={{ marginTop: '8px' }}>
                                                        Word Count: {wordCount}
                                                    </div>
                                                    {touched.description && errors.description && (
                                                        <div className="invalid-feedback">{errors.description}</div>
                                                    )}
                                                </div>
                                            </div>
                                        </div>

                                        <div className="form-group row">
                                            <label className="control-label">Profile Picture</label>
                                            <div className="col-md-12">
                                                <div className="input-group">
                                                    <input
                                                        type="file"
                                                        accept="image/*"
                                                        name="image"
                                                        className={`form-control mr-3 ${touched.image && errors.image ? 'is-invalid' : ''}`}
                                                        onChange={(event) => {
                                                            handleChange(event);
                                                            formik.setFieldValue('image', event.currentTarget.files[0]);
                                                        }}
                                                    />
                                                    {values.image && (
                                                        <img
                                                            src={URL.createObjectURL(values.image)}
                                                            alt="Profile Preview"
                                                            style={{ height: '100px', width: 'auto', marginTop: '8px' }}
                                                        />
                                                    )}
                                                    {touched.image && errors.image && (
                                                        <div className="invalid-feedback">{errors.image}</div>
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                    </fieldset>
                                </div>

                                <Button variant="secondary" onClick={handlePrevStep}>
                                    Previous
                                </Button>
                                <Button variant="success" type="submit" className='float-right'>
                                    Submit
                                </Button>
                                <ToastContainer />
                            </Form>
                        )}
                    </Modal.Body>
                </Modal>
            </div>
        </>
    );
};

export default Profile;
