import React, { useEffect, useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './OwnerDashboard.css'; // Import your custom styles if needed
import { Link } from 'react-router-dom';
import { Outlet , useNavigate } from 'react-router-dom';
import { Dropdown } from 'react-bootstrap';

const OwnerDashboardLayout = () => {
    const [isSidebarOpen, setSidebarOpen] = useState(true);
    const [isDropdownVisible, setDropdownVisible] = useState(false);
    const navigate  = useNavigate()
    const handleLogout = ()=>{
        localStorage.removeItem("owner");
        navigate("/")
    }

    const handleMouseEnter = () => {
        setDropdownVisible(true);
    };
   
    const handleMouseLeave = () => {
        setDropdownVisible(false);
    };
    const toggleSidebar = () => {
        setSidebarOpen(!isSidebarOpen);
    };

    useEffect(() => {

        const sidebarToggle = document.body.querySelector('#sidebarToggle');
        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', event => {
                event.preventDefault();
                document.body.classList.toggle('sb-sidenav-toggled');
                localStorage.setItem('sb|sidebar-toggle', document.body.classList.contains('sb-sidenav-toggled'));
            });
        }
    }, [toggleSidebar]);

    return (
        <div className={`d-flex ${isSidebarOpen ? '' : 'toggled'}`} id="wrapper">
            {/* Sidebar */}
            <div className="border-end  shadow" id="sidebar-wrapper" >
                <div className="sidebar-heading border-bottom bg-dark" >
                    <div>
                        <p style={{ color: "#71c55d" }}><img src="/assets/img/Home.jpeg" style={{ borderRadius: "50px", width: "30px", height: "30px", marginRight: "2%" }} />
                            NayaAshiyana</p>
                    </div>
                </div>
                <div className="list-group  list-group-flush  " style={{backgroundColor:"red"}}>
                    <div className='sidebar-link ' >
                        <Link to="/OwnerDashboard/Profile" className="list-group-item  list-group-item-action list-group-item-light p-3" style={{ color: "white", backgroundColor: "black" }}>
                            <i class="fa fa-user" aria-hidden="true" style={{ color: "#71c55d" }}></i>  Profile
                        </Link>
                    </div>

                    <div className='sidebar-link'>
                        <Link to="/OwnerDashboard/Form1" className="list-group-item list-group-item-action list-group-item-light p-3" style={{ color: "white", backgroundColor: "black" }}>
                            <i class="fa fa-building" style={{ color: "#71c55d" }}></i> Post Property
                        </Link>
                    </div>

                    <div className='sidebar-link'>
                        <Link to="/OwnerDashboard/overview" className="list-group-item list-group-item-action list-group-item-light p-3" style={{ color: "white", backgroundColor: "black" }}>
                            <i class="fa fa-tasks" aria-hidden="true" style={{ color: "#71c55d" }}></i>My Activity
                        </Link>
                    </div>

                    <div className='sidebar-link'>
                        <Link to="/OwnerDashboard/MyListing" className="list-group-item list-group-item-action list-group-item-light p-3" style={{ color: "white", backgroundColor: "black" }}>
                            <i class="fa fa-list-alt" style={{ color: "#71c55d" }}></i> My Listings
                        </Link>
                    </div>

                    <div className='sidebar-link'>
                        <Link to="/profile" className="list-group-item list-group-item-action list-group-item-light p-3" style={{ color: "white", backgroundColor: "black" }}>
                            <i class="fa fa-user-secret" aria-hidden="true" style={{ color: "#71c55d" }}></i>  My Agents
                        </Link>
                    </div>

                    <div className='sidebar-link'>
                        <Link to="/OwnerDashboard/Subs" className="list-group-item list-group-item-action list-group-item-light p-3" style={{ color: "white", backgroundColor: "black" }}>
                            <i class="fa fa-suitcase" aria-hidden="true" style={{ color: "#71c55d" }}></i>  My Services
                        </Link>
                    </div>

                    <div className='sidebar-link'>

                        <Link to="/OwnerDashboard/Subs" className="list-group-item list-group-item-action list-group-item-light p-3" style={{ color: "white", backgroundColor: "black" }}>
                            <i class='fas fa-file-contract' style={{ color: "#71c55d" }}></i>  Rent Aggrements
                        </Link>
                    </div>

                    <div className='sidebar-link'>

                        <Link to="/OwnerDashboard/Subs" className="list-group-item list-group-item-action list-group-item-light p-3" style={{ color: "white", backgroundColor: "black" }}>
                            <i class="fa fa-credit-card" style={{ color: "#71c55d" }}></i> Rent Payments
                        </Link>
                    </div>

                    <div  >

                        <Link to="/OwnerDashboard/Subs" className="list-group-item list-group-item-action list-group-item-light p-3" style={{ color: "white", backgroundColor: "black" }}>
                            <i class='fas fa-file-contract' style={{ color: "#71c55d" }}></i>  Escrow Aggrements
                        </Link>
                    </div>
                </div>
            </div>


            <div id="page-content-wrapper">
                <nav class="navbar navbar-expand-lg navbar-light bg-dark border-bottom shadow">
                    <div class="container-fluid">
                        <button class="btn btn-primary" id="sidebarToggle" onClick={toggleSidebar}> <i class="fas fa-sign-out-alt fa-flip-horizontal"></i></button>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" style={{ backgroundColor: "white" }}><span class="navbar-toggler-icon" ></span></button>
                        <div className="collapse navbar-collapse" style={{ Color: "white" }} id="navbarSupportedContent">
                            <ul className="navbar-nav ms-auto mt-2 mt-lg-0">
                                <li className="nav-item active">
                                    <a className="nav-link text-white" href="/">
                                        Home
                                    </a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link text-white" href="/link">
                                        Link
                                    </a>
                                </li>
                                <div
                                    className="dropdown-container mt-2"
                                    onMouseEnter={handleMouseEnter}
                                    onMouseLeave={handleMouseLeave}
                                >
                                    <a className="dropdown-button  dropdown-toggle text-white" type="button">
                                        Dropdown
                                    </a>
                                    {isDropdownVisible && (
                                        <div className="dropdown-popup" style={{overflow:"hidden"}}>
                                            
                                            <Link to="/OwnerDashboard/Profile" className="list-group-item  list-group-item-action list-group-item-light p-2" >
                                                Profile
                                            </Link>
                                           
                                            <Link to="/OwnerDashboard/Form1" className="list-group-item list-group-item-action list-group-item-light p-2" >
                                                Post Property
                                            </Link>
                                           
                                            <Link to="/OwnerDashboard/overview" className="list-group-item list-group-item-action list-group-item-light p-2" >
                                                My Activity
                                            </Link>
                                            
                                            {/*  */}
                                            <Link to="/OwnerDashboard/MyListing"  className="list-group-item list-group-item-action list-group-item-light p-2" >
                                                My Listings
                                            </Link>
                                            {/*  */}

                                            <Link to="/profile" className="list-group-item list-group-item-action list-group-item-light p-2" >
                                                My Agents
                                            </Link>

                                            <Link to="/OwnerDashboard/Subs" className="list-group-item list-group-item-action list-group-item-light p-2" >
                                                My Services
                                            </Link>
                                            <Link to="/OwnerDashboard/Subs" className="list-group-item list-group-item-action list-group-item-light p-2" >
                                                Rent Aggrements
                                            </Link>
                                            <Link to="/OwnerDashboard/Subs" className="list-group-item list-group-item-action list-group-item-light p-2" >
                                                Rent Payments
                                            </Link>
                                            <Link to="/OwnerDashboard/Subs" className="list-group-item list-group-item-action list-group-item-light p-2" >
                                                Escrow Aggrements
                                            </Link>

                                            {/*  */}
                                        </div>
                                    )}
                                </div>
                                <li className="nav-item">
                                    <a className="nav-link text-white" onClick={handleLogout}>
                                       <button className='btn btn-danger'>Log Out</button> 
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>


                <div className="container-fluid">
                    <Outlet />
                </div>
            </div>
        </div>
    );
};

export default OwnerDashboardLayout;