import React from 'react'

function Mess() {
    return (
        <section id="pricing" class="padd-section text-cente">

            <div class="container" data-aos="fade-up">
                <div class="section-title text-center">

                    <h1 style={{ color: "#71c55d" }}>Here is the featured Mess</h1>
                    <p class="separator" >You can explore more mess by clicking  <br ></br>this button <button className='btn btn-success' style={{borderRadius:"30px"}}>Mess Section</button>  .</p>
                </div>

                <div class="row" data-aos="fade-up" data-aos-delay="100">

                    <div class="col-md-6 col-lg-3">
                        <div class="block-pricing">
                            <div class="pricing-table">
                                <h4>basic</h4>
                                <h2>$29</h2>
                                <ul class="list-unstyled">
                                    <li><b>4 GB</b> Ram</li>
                                    <li><b>7/24</b> Tech Support</li>
                                    <li><b>40 GB</b> SSD Cloud Storage</li>
                                    <li>Monthly Backups</li>
                                    <li>Palo Protection</li>
                                </ul>
                                <div class="table_btn">
                                    <a href="#" class="btn"><i class="bi bi-cart"></i> Buy Now</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6 col-lg-3">
                        <div class="block-pricing">
                            <div class="pricing-table">
                                <h4>PERSONAL</h4>
                                <h2>$29</h2>
                                <ul class="list-unstyled">
                                    <li><b>4 GB</b> Ram</li>
                                    <li><b>7/24</b> Tech Support</li>
                                    <li><b>40 GB</b> SSD Cloud Storage</li>
                                    <li>Monthly Backups</li>
                                    <li>Palo Protection</li>
                                </ul>
                                <div class="table_btn">
                                    <a href="#" class="btn"><i class="bi bi-cart"></i> Buy Now</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6 col-lg-3">
                        <div class="block-pricing">
                            <div class="pricing-table">
                                <h4>BUSINESS</h4>
                                <h2>$29</h2>
                                <ul class="list-unstyled">
                                    <li><b>4 GB</b> Ram</li>
                                    <li><b>7/24</b> Tech Support</li>
                                    <li><b>40 GB</b> SSD Cloud Storage</li>
                                    <li>Monthly Backups</li>
                                    <li>Palo Protection</li>
                                </ul>
                                <div class="table_btn">
                                    <a href="#" class="btn"><i class="bi bi-cart"></i> Buy Now</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6 col-lg-3">
                        <div class="block-pricing">
                            <div class="pricing-table">
                                <h4>profeesional</h4>
                                <h2>$29</h2>
                                <ul class="list-unstyled">
                                    <li><b>4 GB</b> Ram</li>
                                    <li><b>7/24</b> Tech Support</li>
                                    <li><b>40 GB</b> SSD Cloud Storage</li>
                                    <li>Monthly Backups</li>
                                    <li>Palo Protection</li>
                                </ul>
                                <div class="table_btn">
                                    <a href="#" class="btn"><i class="bi bi-cart"></i> Buy Now</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    )
}

export default Mess