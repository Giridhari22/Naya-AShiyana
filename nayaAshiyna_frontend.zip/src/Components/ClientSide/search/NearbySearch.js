import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

function NearbySearch() {
  const [city, setCity] = useState(null);
  const navigate =   useNavigate()

  useEffect(() => {
    // Step 1: Get user coordinates
    function getCoordinates() {
      var options = {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0,
      };

      function success(pos) {
        var crd = pos.coords;
        var lat = crd.latitude.toString();
        var lng = crd.longitude.toString();
        var coordinates = [lat, lng];
        console.log(`Latitude: ${lat}, Longitude: ${lng}`);
        getCity(coordinates);
      }

      function error(err) {
        console.warn(`ERROR(${err.code}): ${err.message}`);
      }

      navigator.geolocation.getCurrentPosition(success, error, options);
    }

    // Step 2: Get city name
    function getCity(coordinates) {
      var xhr = new XMLHttpRequest();
      var lat = coordinates[0];
      var lng = coordinates[1];

      // Paste your LocationIQ token below.
      xhr.open(
        'GET',
        `https://us1.locationiq.com/v1/reverse.php?key=pk.6be4a21cb0fb2aa0000b8fc25f1b0e78&lat=${lat}&lon=${lng}&format=json`,
        true
      );
      xhr.send();
      xhr.onreadystatechange = processRequest;

      function processRequest(e) {
        if (xhr.readyState === 4 && xhr.status === 200) {
          var response = JSON.parse(xhr.responseText);
          console.log({response})
          const locationData = {
                        city: response.address.city,
                        country:response.address.country,
                        country_code:response.address.country_code,
                        state:response.address.state,
                        postcode:response.address.postcode,
                        // area: area,
                        latitude: response.lat,
                        longitude: response.lng,
                      };
        
                      const city = response.address.city
          console.log("city",locationData.city);
          console.log("locationData", locationData)
          localStorage.setItem("Nearby" ,city)
          setCity(locationData); // Set the city in the component's state
        }
      }
    }

    getCoordinates();
  }, []);

   useEffect(() => {
    if (city) {
      navigate("/ProductFilter");
    }
  }, [city, navigate]);
  
  // navigate("/ProductFilter")

  // return (
  //   <div>
  //     <h1>Geolocation - City</h1>
  //     {city && <p>City: {city}</p>}
  //   </div>
  // );
}

export default NearbySearch;

// import React, { useEffect, useState } from 'react';
// import { useNavigate } from 'react-router-dom';

// function NearbySearch() {
//   const [locationInfo, setLocationInfo] = useState(null);
//   const navigate = useNavigate();

//   useEffect(() => {
//     // Step 1: Get user coordinates
//     function getCoordinates() {
//       var options = {
//         enableHighAccuracy: true,
//         timeout: 10000,
//         maximumAge: 0,
//       };

//       function success(pos) {
//         var crd = pos.coords;
//         var lat = crd.latitude.toString();
//         var lng = crd.longitude.toString();
//         console.log(`Latitude: ${lat}, Longitude: ${lng}`);
//         getCity(lat, lng);
//       }

//       function error(err) {
//         console.warn(`ERROR(${err.code}): ${err.message}`);
//       }

//       navigator.geolocation.getCurrentPosition(success, error, options);
//     }

//     // Step 2: Get city and area name
//     function getCity(lat, lng) {
//       // Replace 'YOUR_GOOGLE_MAPS_API_KEY' with your actual API key
//       var apiKey = 'YOUR_GOOGLE_MAPS_API_KEY';
//       var url = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&key=${apiKey}`;


//       fetch(url)
//         .then(response => response.json())
//         .then(data => {
//           var city, area;

//           // Check if the response contains results
//           if (data.results && data.results.length > 0) {
//             const addressComponents = data.results[0].address_components;

//             console.log("Address Components:", addressComponents);

//             // Find the city
//             const cityComponent = addressComponents.find(component => component.types.includes('locality') && component.types.includes('political'));
//             city = cityComponent ? cityComponent.long_name : null;

//             // Find the neighborhood or area
//             const areaComponent = addressComponents.find(component => component.types.includes('neighborhood') || component.types.includes('sublocality') || component.types.includes('locality'));
//             area = areaComponent ? areaComponent.long_name : null;
//           }
//           console.log("City:", city);
//           console.log("Area:", area);
//           console.log("Latitude:", lat);
//           console.log("Longitude:", lng);

//           const locationData = {
//             city: city,
//             area: area,
//             latitude: lat,
//             longitude: lng,
//           };

//           setLocationInfo(locationData);
//           localStorage.setItem("Nearby", JSON.stringify(locationData));
//         })
//         .catch(error => {
//           console.error("Error fetching data from Google Maps API:", error);
//         });
//     }

//     getCoordinates();
//   }, []);

//   // useEffect(() => {
//   //   if (locationInfo) {
//   //     navigate("/ProductFilter");
//   //   }
//   // }, [locationInfo, navigate]);

//   return (
//     <div>
//       {/* Add UI rendering for locationInfo if needed */}
//     </div>
//   );
// }

// export default NearbySearch;
